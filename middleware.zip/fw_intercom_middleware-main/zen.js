const getAppid = async () => {
  const options = {
    url: `/api/v2/apps/owned.json`,
    type: "GET",
    // headers: { Authorization: `Basic ${base64}` },
    contentType: "application/json",

    secure: true,
  };

  try {
    let data = await client.request(options);

    const app_data = data.apps?.filter(
      (app) => app.name === "Zendesk zohoCRM sync"
    );
    appId = app_data[0].id;
  } catch (error) {
    console.error(error);
  }
};
