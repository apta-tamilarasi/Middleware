require("dotenv").config();

const { MongoClient } = require("mongodb");
const { deleteFiles } = require("./monday_files");
// const accountSid = "AC92bf1c69c4a3f2dd86c60c127452b0d0";
// const authToken = "7db98627a779671673565c1727ff8b82";
// const client = require("twilio")(accountSid, authToken);

// const uri =
//   "mongodb+srv://arokiyakithiyon:Kithi%4004@vteck.6h8noxc.mongodb.net/?retryWrites=true&w=majority&tls=true";
const uri = "mongodb://admin:Dineshviji%4016@127.0.0.1:27017/?authSource=admin";
const client = new MongoClient(uri);

// const createWebhook = async (req, res) => {
//   console.log("yes");
//   console.log(req.body);
//   const { account_id } = req.body;
//   const data = await retrivedata(account_id);
//   console.log(data);

//   const { payload } = req.body;
//   const { boardId } = payload.inputFields;
//   const accountSid = "AC92bf1c69c4a3f2dd86c60c127452b0d0";

//   const authToken = "7db98627a779671673565c1727ff8b82";
//   const client = twilio(accountSid, authToken);
//   const webhook = await client
//     .incomingPhoneNumbers("PNf8d6183af88db883be03bc320f60371b")
//     .update({
//       smsUrl: `https://strongly-touched-python.ngrok-free.app/monday/twilio/incomming_message/${boardId}/${account_id}`,
//       smsMethod: "POST",
//     });
//   console.log(webhook);
//   res.sendStatus(200);
// };

const sendIncommingMessageToMonday = async (req, res) => {
  console.log(req.params);
  console.log(req.body);

  const { boardId, accountId } = req.params;

  try {
    const settingsData = await retrivedata(accountId);
    console.log(settingsData);

    const payload = {
      trigger: {
        outputFields: {
          boardId,
          twilioBody: {
            twilio_data: req.body,
            settings_data: settingsData,
            accountId,
          },
        },
      },
    };
    if(settingsData.incomming_webhook_url === ""){
      res.set("Content-Type", "text/xml");
      res.send("<Response>We have stopped receiving messages from this account</Response>");
      return 
    }
    const response = await fetch(settingsData.incomming_webhook_url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `f904ca77b054d355a330784819911d2b`,
      },
      body: JSON.stringify(payload),
    });
    //console.log(response);
    const data = await response.json();
    console.log(data);
    res.set("Content-Type", "text/xml");
    res.send("<Response></Response>");
  } catch (error) {
    //console.error(error.response);
    console.error("Error sending message to Monday:", error);

    res.set("Content-Type", "text/xml");
    res.send("<Response></Response>");
  }
};

const saveMondaySettingsPayload = async (req, res) => {
  console.log(req.body);
  const { payload } = req.body;

  try {
    await client.connect();
    const database = client.db("monday_twilio");
    const collection = database.collection("settings");

    const filter = { account_id: payload.account_id }; // check by account_id
    const update = { $set: payload }; // replace entire document with new payload
    const options = { upsert: true }; // insert if not found

    const result = await collection.updateOne(filter, update, options);

    if (result.upsertedCount > 0) {
      console.log(`New document inserted with id: ${result.upsertedId._id}`);
      res.status(200).json({ message: "Data inserted successfully" });
    } else {
      console.log(`Document with account_id ${payload.account_id} updated`);
      res.status(200).json({ message: "Data updated successfully" });
    }
  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).json({ error: "Failed to save data" });
  } finally {
    await client.close();
  }
};

const retriveMondaySettingsPayload = async (req, res) => {
  try {
    const { accountId } = req.params;
    const data = await retrivedata(accountId);
    console.log("data :", data);
    if (data?.error) {
      res.status(500).json({ error: "Failed to retrieve data" });
    } else {
      res.status(200).json(data);
    }
  } catch (error) {
    console.error("Error retrieving data:", error);
    res.status(500).json({ error: "Failed to retrieve data" });
  }
};
const updateMondaySettingsPayload = async (req, res) => {
  const { accountId, webhookUrl } = req.body;
  const data = await updateData(accountId, webhookUrl);
  console.log("data :", data);

  if (data) res.status(200).json(data);
  else res.status(500).json({ error: "Failed to update data" });
};
const retrivedata = async (accountId) => {
  try {
    await client.connect();
    const database = client.db("monday_twilio");
    const collection = database.collection("settings");

    const data = await collection.findOne({ account_id: accountId });
    console.log(data);

    return data;
  } catch (error) {
    console.error("Error retrieving data:", error);
    return { error: "Failed to retrieve data" };
  } finally {
    await client.close();
  }
};

const updateData = async (accountId, url) => {
  try {
    await client.connect();
    const database = client.db("monday_twilio");
    const collection = database.collection("settings");

    const data = await collection.findOneAndUpdate(
      { account_id: `${accountId}` },
      { $set: { incomming_webhook_url: url } },
      { returnDocument: "after", upsert: false }
    );
    //   console.log(data);

    return data;
  } catch (error) {
    console.error("Error retrieving data:", error);
    return null;
  } finally {
    await client.close();
  }
};

const saveMessageInDb = async (req, res) => {
  console.log(req.body);
  // const { payload } = req.body;
  // console.log(payload);
  try {
    await client.connect();
    const database = client.db("monday_twilio_messages");
    const collection = database.collection("md_tw_messages");

    const result = await collection.insertOne(req.body);
    console.log(`data saved with id: ${result.insertedId}`);

    res.status(200).json({ message: "data saved successfully" });
  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).json({ error: "Failed to save data" });
  } finally {
    await client.close();
  }
};

const getMessages = async (req, res) => {
  const { accountId, itemId } = req.params;
  const { limit, page } = req.query;

  // Input validation
  const parsedLimit = parseInt(limit) || 10; // Default to 10 if not provided or invalid
  const parsedPage = parseInt(page) || 1; // Default to 1 if not provided or invalid

  if (parsedLimit < 1 || parsedPage < 1) {
    return res.status(400).json({ message: "Invalid pagination parameters" });
  }

  try {
    await client.connect();
    const database = client.db("monday_twilio_messages");
    const collection = database.collection("md_tw_messages");

    const filter = {
      accountId: `${accountId}`,
      itemId: Number(itemId),
    };
    console.log(filter);

    const totalCount = await collection.countDocuments(filter);

    const messages = await collection
      .find(filter)
      .sort({ _id: -1 })
      .skip((parsedPage - 1) * parsedLimit)
      .limit(parsedLimit)
      .toArray();

    const totalPages = Math.ceil(totalCount / parsedLimit);

    res.status(200).json({
      currentPage: parsedPage,
      totalPages,
      totalMessages: totalCount,
      hasNextPage: parsedPage < totalPages,
      data: messages,
    });
  } catch (err) {
    console.error("Error:", err);
    res.status(500).json({ message: "Something went wrong" });
  } finally {
    await client.close();
  }
};

const deleteData = async (req, res) => {
  const { accountId } = req.params;

  // Input validation
  if (!accountId) {
    return res.status(400).json({ error: "Account ID is required" });
  }

  try {
    await client.connect();
    const database = client.db("monday_twilio_messages");
    const collection = database.collection("md_tw_messages");
    const filter = { accountId };
    
    const result = await collection.deleteMany(filter);
    
    const SettingsDatabase = client.db("monday_twilio");
    const SettingsCollection = SettingsDatabase.collection("settings");
    const SettingsFilter = { account_id: accountId };
    
    const SettingsResult = await SettingsCollection.deleteOne(SettingsFilter);
    
    console.log(`Deleted ${result.deletedCount} messages and ${SettingsResult.deletedCount} settings document`);
    await deleteFiles(accountId);
    return res.status(200).json({ 
      message: "Data deleted successfully",
      deletedMessages: result.deletedCount,
      deletedSettings: SettingsResult.deletedCount
    });
  } catch (error) {
    console.error("Error deleting documents:", error);
    return res.status(500).json({ 
      error: "Failed to delete data",
      details: error.message 
    });
  } finally {
    await client.close();
  }
};
const updateWebhookUrl =async (req,res)=>{
  const {accountId,webhookUrl}=req.body;
  console.log(accountId,webhookUrl);
  try {
    await client.connect()
    const database = client.db("monday_twilio");
    const collection = database.collection("settings");
    const filter = { account_id: accountId };
    const update = { $set: { incomming_webhook_url: webhookUrl } };
    const options = { upsert: true };
    const result = await collection.updateOne(filter, update, options);
    if (result.upsertedCount > 0) {
      console.log(`New document inserted with id: ${result.upsertedId._id}`);
      res.status(200).json({ message: "Data inserted successfully" });
    } else {
      console.log(`Document with account_id ${accountId} updated`);
      res.status(200).json({ message: "Data updated successfully" })
    }
  } catch (error) {
    console.error("Error updating data:", error);
    res.status(500).json({ error: "Failed to update data" });
  } finally {
    await client.close();
  }
}
module.exports = {
  // createWebhook,
  sendIncommingMessageToMonday,
saveMondaySettingsPayload,
  retriveMondaySettingsPayload,
  updateMondaySettingsPayload,
  saveMessageInDb,
  getMessages,
  deleteData,
  updateWebhookUrl
};
