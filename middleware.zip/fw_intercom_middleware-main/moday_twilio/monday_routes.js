let express = require("express");
const router = express.Router();
const helper = require("./helper");

//router.post("/subscribe", mondayRoutes.createWebhook);
router.post(
  "/incomming_message/:boardId/:accountId",
  helper.sendIncommingMessageToMonday
);

router.post("/save", helper.saveMondaySettingsPayload);
router.get("/retrieve/:accountId", helper.retriveMondaySettingsPayload);
router.post("/update", helper.updateMondaySettingsPayload);
router.post("/saveMessage", helper.saveMessageInDb);
//router.delete("/delete", mondayRoutes.deleteMondaySettingsPayload);
router.get("/conversation/:accountId/:itemId", helper.getMessages);
router.delete("/delete/:accountId", helper.deleteData);
router.put("/remove/webhook_url", helper.updateWebhookUrl);
module.exports = router;
