const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const BASE_DIR = path.join(__dirname, "../../", "monday_twilio_files");

// Ensure base directory exists
if (!fs.existsSync(BASE_DIR)) {
  fs.mkdirSync(BASE_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const accountId = req.params.accountId;
    if (!accountId) {
      return cb(new Error("account_id is required"));
    }

    const folderPath = path.join(BASE_DIR, accountId);
    if (!fs.existsSync(folderPath)) {
      fs.mkdirSync(folderPath, { recursive: true });
    }

    cb(null, folderPath);
  },
  filename: function (req, file, cb) {
    const sanitized = file.originalname.replace(/\s+/g, "-");
    cb(null, `${Date.now()}-${sanitized}`);
  },
});

const upload = multer({
  storage: storage,
});

router.post("/upload/:accountId", upload.array("files", 5), (req, res) => {
  console.log("yes");

  try {
    console.log("Files received:", req.files);
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: "No files uploaded." });
    }

    const accountId = req.params.accountId;
    const urls = req.files.map((file) => {
      return `https://api.vtecknologies.com/monday/files/uploads/${accountId}/${path.basename(
        file.path
      )}`;
    });
    console.log(urls);

    res.status(200).json({
      message: "Files uploaded successfully.",
      files: urls,
    });
  } catch (error) {
    console.error("File upload error:", error);
    if (error.code === "LIMIT_FILE_SIZE") {
      return res
        .status(413)
        .json({ error: "File size too large. Maximum size is 10MB." });
    }
    res.status(500).json({ error: "Failed to upload files" });
  }
});

// File download endpoint
router.get("/uploads/:accountId/:fileName", (req, res) => {
  try {
    const { accountId, fileName } = req.params;
    const filePath = path.join(BASE_DIR, accountId, fileName);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: "File not found" });
    }
    res.setHeader("Access-Control-Allow-Origin", req.headers.origin || "*");
    res.sendFile(filePath);
  } catch (error) {
    console.error("File download error:", error);
    res.status(500).json({ error: "Failed to download file" });
  }
});

const deleteFiles = async (accountId) => {
  try {
  
    const folderPath = path.join(BASE_DIR, accountId);
    
 
    if (!fs.existsSync(folderPath)) {
      console.log(`No uploads found for account ${accountId}`);
      return {
        success: true,
        message: "No uploads found for this account"
      };
    }

   
    const files = await fs.promises.readdir(folderPath);
    console.log(`Found ${files.length} files to delete for account ${accountId}`);

  
    await fs.promises.rm(folderPath, { recursive: true, force: true });
    
    return {
      success: true,
      message: `Successfully deleted ${files.length} files for account ${accountId}`,
      deletedFiles: files
    };
  } catch (error) {
    console.error(`Error while deleting files for account ${accountId}:`, error);
    throw new Error(`Failed to delete files: ${error.message}`);
  }
};

module.exports = router;
module.exports.deleteFiles = deleteFiles;
