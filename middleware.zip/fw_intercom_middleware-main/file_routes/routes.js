const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const BASE_DIR = path.join(__dirname, "../../", "uploads");

if (!fs.existsSync(BASE_DIR)) {
  fs.mkdirSync(BASE_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const accountId = req.params.accountId;
    if (!accountId) return cb(new Error("account_id is required"));

    const folderPath = path.join(BASE_DIR, accountId);
    if (!fs.existsSync(folderPath)) {
      fs.mkdirSync(folderPath, { recursive: true });
    }

    cb(null, folderPath);
  },
  filename: function (req, file, cb) {
    const sanitized = file.originalname.replace(/\s+/g, "-");
    cb(null, `${Date.now()}-${sanitized}`);
  },
});

const upload = multer({ storage: storage });

// Upload endpoint
router.post("/upload/:accountId", upload.array("twilio", 5), (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ error: "No files uploaded." });
  }

  const accountId = req.params.accountId;
  const urls = req.files.map((file) => {
    //return `https://strongly-touched-python.ngrok-free.app/fd_twilio/files/uploads/${accountId}/${file.filename}`;

    return `https://api.vtecknologies.com/fd_twilio/files/uploads/${accountId}/${path.basename(
      file.path
    )}`;
  });
  console.log(urls);

  res.status(200).json({
    message: "Files uploaded successfully.",
    files: urls,
  });
});

router.get("/uploads/:accountId/:fileName", (req, res) => {
  const { accountId, fileName } = req.params;
  const BASE_DIR = path.join(__dirname, "../../uploads");
  const filePath = path.join(BASE_DIR, accountId, fileName);
  console.log(filePath);

  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    res.status(404).json({ error: "File not found" });
  }
});

module.exports = router;
