const fs = require("fs");
const path = require("path");

const deleteFDTWAccountFolder = (accountId) => {
  const folderPath = path.join(__dirname, "../../", "uploads", accountId);
  console.log(folderPath);

  if (fs.existsSync(folderPath)) {
    fs.rm(folderPath, { recursive: true, force: true }, (err) => {
      if (err) {
        console.error(`Failed to delete folder for account ${accountId}:`, err);
      } else {
        console.log(`✅ Folder deleted for account ${accountId}`);
      }
    });
  } else {
    console.log(`⚠️ Folder not found for account ${accountId}`);
  }
};

module.exports = {
  deleteFDTWAccountFolder,
};
