const express = require("express");
const { MongoClient } = require("mongodb");

const router = express.Router();

const uri = "mongodb+srv://tamilarasi:e9JHgS8ERodRDyLS@vteck.l4vzghm.mongodb.net/?retryWrites=true&w=majority&appName=vteck";

const client = new MongoClient(uri);

let db;

const connectDB = async () => {
  try {
    if (!db) {
      await client.connect();
      console.log("✅ MongoDB connected successfully");
      db = client.db("quickbooks");
    }
  } catch (error) {
    console.error("❌ MongoDB connection error:", error);
    throw error; 
  }
};

router.use(async (req, res, next) => {
  try {
    if (!db) {
      await connectDB(); 
    }
    next();
  } catch (error) {
    res.status(500).json({ message: "Failed to connect to database", error });
  }
});

router.get("/", (req, res) => {
  res.send("<p>Hello Quick Book and Monday.com Integration</p>");
});

router.post("/store-quickbook-invoice", async (req, res) => {
  try {
    const database = db;
    const collection = database.collection("invoices");

    const invoiceData = req.body;
    console.log(invoiceData)

    if (!invoiceData || Object.keys(invoiceData).length === 0) {
      return res.status(400).json({ message: "No invoice data provided" });
    }

    const existing = await collection.findOne({ Id: invoiceData.Id });

    if (existing) {
      await collection.updateOne({ Id: invoiceData.Id }, { $set: invoiceData });
      console.log("🔄 Invoice updated:", existing._id);
      return res.status(200).json({ message: "Invoice updated successfully", id: existing._id });
    } else {
      const result = await collection.insertOne(invoiceData);
      console.log("🆕 Invoice inserted:", result.insertedId);
      return res.status(200).json({ message: "Invoice stored successfully", id: result.insertedId });
    }

  } catch (error) {
    console.error("❌ Error storing invoice:", error);
    return res.status(500).json({ message: "Failed to store invoice", error });
  }
});

router.get("/invoice/:id", async (req, res) => {
  const invoiceId = req.params.id;
  console.log(invoiceId);

  try {
    const database = db;
    const collection = database.collection("invoices");
    const invoice = await collection.findOne({ Id: invoiceId });

    if (invoice) {
      return res.status(200).json(invoice);
    } else {
      return res.status(404).json({ message: "Invoice not found" });
    }
  } catch (error) {
    console.error("❌ Error fetching invoice:", error);
    return res.status(500).json({ message: "Failed to fetch invoice", error });
  }
});

router.get("/invoices", async (req, res) => {
  try {
    const database = db;
    const collection = database.collection("invoices");

    const invoices = await collection.find().toArray();

    if (invoices.length > 0) {
      return res.status(200).json(invoices);  
    } else {
      return res.status(200).json([]);
    }
  } catch (error) {
    console.error("❌ Error fetching invoices:", error);
    return res.status(500).json({ message: "Failed to fetch invoices", error });
  }
});

router.post("/store-quickbook-customer", async (req, res) => {
  try {
    const database = db;
    const collection = database.collection("customers");

    const customerData = req.body;
    console.log(customerData);

    if (!customerData || Object.keys(customerData).length === 0) {
      return res.status(400).json({ message: "No customer data provided" });
    }

    // const existing = await collection.findOne({ Id: customerData.Id });

    // if (existing) {
    //   return res.status(400).json({ message: "Customer already exists" });
    // } else {
      const result = await collection.insertOne(customerData);
      console.log("🆕 Customer inserted:", result.insertedId);
      return res.status(200).json({
        message: "Customer stored successfully",
        id: result.insertedId,
      });
    // }

  } catch (error) {
    console.error("❌ Error storing customer:", error);
    return res.status(500).json({ message: "Failed to store customer", error });
  }
});

router.get("/customer/:id", async (req, res) => {
  const customerId = req.params.id;
  console.log(customerId);

  try {
    const database = db;
    const collection = database.collection("customers");
    const customer = await collection.findOne({ Id:customerId});

    if (customer) {
      return res.status(200).json(customer);
    } else {
      return res.status(404).json({ message: "Customer not found" });
    }
  } catch (error) {
    console.error("❌ Error fetching customer:", error);
    return res.status(500).json({ message: "Failed to fetch customer", error });
  }
});

router.get("/customers", async (req, res) => {
  try {
    const database = db;
    const collection = database.collection("customers");

    const customers = await collection.find().toArray();

    if (customers.length > 0) {
      return res.status(200).json(customers);  
    } else {
      return res.status(200).json([]);
    }
  } catch (error) {
    console.error("❌ Error fetching customers:", error);
    return res.status(500).json({ message: "Failed to fetch customers", error });
  }
});

router.put("/customerEdit/:id", async (req, res) => {
  const customerId = req.params.id;
  const updatedData = req.body;

  try {
    const database = db;
    const collection = database.collection("customers");

    const customer = await collection.findOne({ Id:customerId });

    if (!customer) {
      return res.status(404).json({ message: "Customer not found" });
    }

    const result = await collection.updateOne(
      { Id:customerId  },
      { $set: updatedData }
    );
    console.log("🔄 Customer updated:", customerId);
    return res.status(200).json({ message: "Customer updated successfully", id: customerId });

  } catch (error) {
    console.error("❌ Error updating customer:", error);
    return res.status(500).json({ message: "Failed to update customer", error });
  }
});

router.put("/invoiceEdit/:id", async (req, res) => {
  const invoiceId = req.params.id;
  const updatedData = req.body;

  try {
    const database = db;
    const collection = database.collection("invoices");

    const invoice = await collection.findOne({ _id: new MongoClient.ObjectId(invoiceId) });

    if (!invoice) {
      return res.status(404).json({ message: "invoiceId not found" });
    }

    const result = await collection.updateOne(
      { _id: new MongoClient.ObjectId(invoiceId) },
      { $set: updatedData }
    );
    console.log("🔄 invoiceId updated:", invoiceId);
    return res.status(200).json({ message: "Customer updated successfully", id:invoiceId });

  } catch (error) {
    console.error("❌ Error updating customer:", error);
    return res.status(500).json({ message: "Failed to update customer", error });
  }
});

module.exports = router;
