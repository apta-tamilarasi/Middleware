require("dotenv").config();
let express = require("express");
const router = express.Router();
//const constants = require("../constant");
const helpers = require("../helpers");
//let db = helpers.getConnection();
const { MongoClient } = require("mongodb");
const { deleteFDTWAccountFolder } = require("../file_routes/files_helper");
const uri = "mongodb://admin:Dineshviji%4016@127.0.0.1:27017/?authSource=admin";
console.log(uri);

const client = new MongoClient(uri);
//console.log(client);

router.get("/", (req, res) => {
  res.send("<h1>yehh twilioo..</h1>");
});

router.post("/conversation", async (req, res) => {
  const { account_id, ticket_id, message, sender, media_urls } = req.body;
  console.log(req.body);

  const payload = {
    ticket_id: Number(ticket_id),
    account_id: Number(account_id),
    message,
    sender,
    media_urls,
  };
  try {
    await client.connect();
    const database = client.db("freshdesk_twilio");
    const collection = database.collection("twilio_messages");

    const result = await collection.insertOne(payload);
    console.log(`data saved with id: ${result.insertedId}`);

    res.status(200).json({ message: "data saved successfully" });
  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).json({ error: "Failed to save data" });
  } finally {
    await client.close();
  }
  // SHOW COLUMNS FROM twilio_messages;
  // db.query("SHOW TABLES LIKE 'twilio_messages'", function (err, results) {
  //   if (err) {
  //     console.log(err);

  //     return res.status(500).json({ error: err.message });
  //   }
  //   console.log(results);

  //   if (results.length > 0) {
  //     res.status(200).json({ message: "twilio_messages table exists" });
  //   } else {
  //     res.status(404).json({ message: "twilio_messages table does not exist" });
  //   }
  // });

  // db.query(
  //   constants.TWILIO.TW_INSERT,
  //   [account_id, ticket_id, message, sender, mediaUrlsJSON],
  //   function (err) {
  //     if (err) return res.status(500).json({ error: err.message });
  //     res.status(201).json({ id: this.lastID, message: "Conversation added" });
  //   }
  // );
});

router.get("/conversation/:account_id/:ticket_id", async (req, res) => {
  const { account_id, ticket_id } = req.params;
  const { limit, page } = req.query;
  //console.log(req.query);
  //const offset = (Number(page) - 1) * Number(limit);
  //console.log(offset);
  console.log("yes");

  // const mediaUrlsJSON =
  //   media_urls.length > 0 ? JSON.stringify(media_urls) : null;
  // const limit = 20; // Number of records per page (example)
  // const offset = 0;
  // db.query(
  //   constants.TWILIO.TW_GET,
  //   [account_id, ticket_id, Number(limit) + 1, offset],
  //   (err, rows) => {
  //     if (err) {
  //       console.log(err);

  //       return res.status(500).json({ error: err.message });
  //     }

  //     if (rows.length === 0) {
  //       return res.status(404).json({ message: "No conversation found" });
  //     }
  //     const hasNextPage = rows.length > limit;
  //     if (hasNextPage) {
  //       rows.pop();
  //     }
  //     console.log(rows);

  //     return res.status(200).json({ data: rows, hasNextPage });
  //   }
  // );

  //const { ticket_id, account_id, page = 1, limit = 10 } = req.query;
  await client.connect();
  const database = client.db("freshdesk_twilio");
  const collection = database.collection("twilio_messages");
  console.log(account_id, ticket_id);

  try {
    const filter = {
      ticket_id: Number(ticket_id),
      account_id: Number(account_id),
    };

    const totalCount = await collection.countDocuments(filter);

    const messages = await collection
      .find(filter)
      .sort({ _id: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .toArray();

    const currentPage = Number(page);
    const totalPages = Math.ceil(totalCount / limit);
    console.log(messages);

    res.status(200).json({
      currentPage,
      totalPages,
      totalMessages: totalCount,
      hasNextPage: currentPage < totalPages,
      data: messages,
    });
  } catch (err) {
    console.error("Error:", err);
    res.status(500).json({ message: "Something went wrong" });
  } finally {
    await client.close();
  }
});

router.delete("/conversation/:account_id/:ticket_id", async (req, res) => {
  const { account_id, ticket_id } = req.params;
  console.log(req.params);
  try {
    await client.connect();
    const database = client.db("freshdesk_twilio");
    const collection = database.collection("twilio_messages");

    const filter = {
      account_id: Number(account_id),
      ticket_id: Number(ticket_id),
    };

    const result = await collection.deleteMany(filter);

    res.status(200).json({
      message: `${result.deletedCount} Message(s) deleted successfully`,
    });
  } catch (error) {
    console.error("Error deleting documents:", error);
    res.status(500).json({ error: "Failed to delete Messages" });
  } finally {
    await client.close();
  }
  // db.query(
  //   constants.TWILIO.TW_TICKET_DELETE,
  //   [account_id, ticket_id],
  //   (err, rows) => {
  //     if (err) {
  //       console.log(err);

  //       return res.status(500).json({ error: err.message });
  //     }

  //     if (rows.length === 0) {
  //       return res.status(404).json({ message: "No conversation found" });
  //     }
  //     console.log(rows);

  //     return res.status(200).json({ data: rows });
  //   }
  // );
});

router.delete("/account/:account_id", async (req, res) => {
  const { account_id } = req.params;
  console.log(req.params);
  try {
    await client.connect();
    const database = client.db("freshdesk_twilio");
    const collection = database.collection("twilio_messages");

    const result = await collection.deleteMany({
      account_id: Number(account_id),
    });
    const file = deleteFDTWAccountFolder(account_id);
    console.log(file);
    console.log(`${result.deletedCount} Message(s) deleted successfully`);

    res.status(200).json({
      message: `${result.deletedCount} Message(s) deleted successfully`,
    });
  } catch (error) {
    console.error("Error deleting documents:", error);
    res.status(500).json({ error: "Failed to delete Messages" });
  } finally {
    await client.close();
  }

  // db.query(constants.TWILIO.TW_ACCOUNT_DELETE, [account_id], (err, rows) => {
  //   if (err) {
  //     console.log(err);

  //     return res.status(500).json({ error: err.message });
  //   }

  //   if (rows.length === 0) {
  //     return res.status(404).json({ message: "No conversation found" });
  //   }
  //   console.log(rows);

  //   return res.status(200).json({ data: rows });
  // });
});

module.exports = router;
