require("dotenv").config();
const axios = require("axios");
const bodyParser = require("body-parser");
const express = require("express");
const constants = require("./constant");
const helpers = require("./helpers");
const path = require("path");
//const fileUpload = require("express-fileupload");
var zendesk = require("node-zendesk");
let zohoCredentials = {};

const cors = require("cors");
const mondayRoutes = require("./moday_twilio/monday_routes");
const twilioRoutes = require("./twilio/fd_twilio");
const qbMondayRoutes = require("./app/QB_Monday/qbMon");
const fileRoutes = require("./file_routes/routes");
const mondayQbRoutes=require("./monday_qb/monday_routes")
const mondayFileRoutes = require("./moday_twilio/monday_files");
//const imagesDir = path.join(__dirname, "uploadfile/images");

// if (!fs.existsSync(imagesDir)) {
//   fs.mkdirSync(imagesDir, { recursive: true });
// }
const app = express();
app.use(express.json());
//app.use(fileUpload());
const allowedOrigins = [
  "http://localhost:10001",
  "https://d3h0owdjgzys62.cloudfront.net",
  "https://api.vtecknologies.com",
 
];

app.use(
  cors({
    origin: function (origin, callback) {
      // console.log(origin);
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        // callback(null, true);
        callback(new Error("Not allowed by CORS"));
      }
    },
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  })
);
app.use(bodyParser.urlencoded({ extended: true }));

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "app")));
app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

app.use("/twilio", twilioRoutes)
app.use("/mondayqb", qbMondayRoutes);
app.use("/monday/twilio", mondayRoutes);
app.use("/fd_twilio/files", fileRoutes);
app.use("/mondayquickbook",mondayQbRoutes)
app.use("/monday/files", mondayFileRoutes);

//app.options("/upload", cors());
// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, "uploadfile/"); // Destination folder
//   },
//   filename: function (req, file, cb) {
//     // Extract custom filename from request body
//     cb(null, file.originalname.replace(/\s+/g, "-"));
//   },
// });

//const upload = multer({ storage: storage });

//twilio

let db = null;

app.listen(process.env.PORT || 3000, () => {
  console.log(
    `Middleware Server listening at ${process.env.PORT || 3000}... 👍`
  );

  db = helpers.getConnection();
  db.query(constants.CREATE_QUERY);
  db.query(constants.ZEN_CREATE_QUERY);
  db.query(constants.TWILIO.TW_CREATE);
  db.query(constants.CREATE_QBMONDAY_TABLE);
  db.query(constants.CREATE_QBMONDAY_DATA_TABLE);

  // zendb = helpers.getZenConnection();
  // zendb.run(constants.ZEN_CREATE_QUERY);
});

// Dummy end point for testing the deployed url
app.get("/", (req, res, next) => {
  res.send({
    message: constants.GREETINGS,
  });
});

// app.post("/monday/twilio/subscribe", (req, res) => {
//   console.log(req.body);
//   res.status(200);
// });
// need to redesign the api
// receives data from intercom side
// there should be some association with the intercom and url that we use here. else nothing gonna work here
app.post("/", (req, res) => {
  const body = req.body;

  console.log(JSON.stringify(body));
  // if (process.env.URL) {
  axios
    .post(
      "https://hooks4.freshworks.com/dvuJiyGlPR4I6Anaf0S%2FN3sXJE87S%2Fe6eS6Vp3gWhJCukSByWonFu0AuHjd1pkLHivNlzkNdCN8O1WKZ1FNhurCGZJ74PXepYUESjrvi3g%3D%3D",
      { ...body }
    )
    .then((_) => {
      console.log(
        `${constants.MSG} https://hooks4.freshworks.com/dvuJiyGlPR4I6Anaf0S%2FN3sXJE87S%2Fe6eS6Vp3gWhJCukSByWonFu0AuHjd1pkLHivNlzkNdCN8O1WKZ1FNhurCGZJ74PXepYUESjrvi3g%3D%3D`
      );
    })
    .catch((er) => console.error(`Error Occurred: ${JSON.stringify(er)}`));
  res.json({
    message: `${constants.MSG} https://hooks4.freshworks.com/dvuJiyGlPR4I6Anaf0S%2FN3sXJE87S%2Fe6eS6Vp3gWhJCukSByWonFu0AuHjd1pkLHivNlzkNdCN8O1WKZ1FNhurCGZJ74PXepYUESjrvi3g%3D%3D`,
  });
  // } else {
  //   console.log(constants.URL_NOT_REGISTERED);
  //   res.json({
  //     message: constants.URL_NOT_REGISTERED,
  //   });
  // }
});

// for registering users details to middleware
app.post("/register", (req, res) => {
  console.log(`data to register: ${JSON.stringify(req.body)}`);
  const { url, id, app } = req.body;
  if (db == null) db = helpers.getConnection();
  db.query(constants.INSERT_URL, [id, url, app], (err) => {
    if (err) {
      console.error(JSON.stringify(err));
      res.json({ data: `URL ${url} registration failed. \n Error  ${err} ` });
    } else {
      res.json({ data: `URL ${url} registered successfully` });
    }
  });
});
app.get("/home", (req, res) => {
  // const query = `SELECT * FROM zoho`;
  // db.get(query, [], (err, row) => {
  //   if (err) {
  //     console.log(err);
  //   } else {
  //     zohoCredentials = { ...row };
  //     console.log(zohoCredentials);
  //   }
  // });

  res.sendFile(path.join(__dirname, "app", "Zendesk", "iframe.html"));
});

app.post("/isAuth", async (req, res) => {
  const { appId } = req.body;
  let response = await getDataFromDb(appId);
  res.status(200).send(response);
});

app.post("/auth", async (req, res) => {
  const { authorizationCode, clientId, clientSecret, dc, appId } = req.body;

  if (!authorizationCode || !clientId || !clientSecret || !dc || !appId) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  const url = `https://accounts.${dc}/oauth/v2/token?client_id=${clientId}&client_secret=${clientSecret}&grant_type=authorization_code&code=${authorizationCode}`;

  try {
    const response = await axios.post(url);
    if (response.data.error) {
      throw new Error(response.data.error);
    }
    const {
      refresh_token: refreshToken,
      access_token: accessToken,
      api_domain: domain,
    } = response.data;

    if (!db) db = helpers.getConnection();
    await db.query(constants.ZEN_CREATE_QUERY);
    await db.query(constants.ZEN_INSERT_URL, [
      appId,
      clientId,
      clientSecret,
      refreshToken,
      accessToken,
      domain,
    ]);
    res.status(200).json({ message: "Record created successfully" });
  } catch (error) {
    console.error("ERROR: ", error.message || error);
    res.status(500).json({ message: error.message || "Internal server error" });
  }
});

app.get("/zohoCRMfields", (req, res) => {
  getCRMfields(req, res);
});

app.post("/webhook", (req, res) => {
  console.log(req.body);
  const { fields } = req.body;
  if (db == null) db = helpers.getConnection();
  db.query(
    constants.ZEN_UPDATE_FIELDS,
    [JSON.stringify(fields), zohoCredentials.appId],
    function (err) {
      if (err) {
        console.error(err.message);
        res.status(500).send({ message: "Fields not saved" });
        return;
      } else {
        zohoCredentials.fields = JSON.stringify(fields);
        console.log("fields are saved " + this.changes);
        res.status(200).send({ message: "Fields saved successfully" });
      }
    }
  );

  // let obj = {
  //   webhook: {
  //     name: "Zoho_CRM_Webhook",
  //     status: "active",
  //     endpoint: "https://intercom-middleware.onrender.com/crmcontact",
  //     http_method: "POST",
  //     request_format: "json",
  //     subscriptions: ["zen:event-type:user.created"],
  //   },
  // };
  // const url = `https://d3v-kithiyon.zendesk.com/api/v2/webhooks`;
  // const options = {
  //   method: "POST",
  //   headers: {
  //     "content-Type": "application/json",
  //     Authorization: `Basic ${token}`,
  //   },
  // };
  // console.log(options);
  // axios
  //   .post(url, obj, options)
  //   .then((response) => {
  //     console.log(response);
  //     res.send(response);
  //   })
  //   .catch((er) => {
  //     console.error("ERROR : " + er);
  //     res.status(500).send(er);
  //   });
  // const url = "https://d3v-kithiyon.zendesk.com/api/v2/user_fields";

  // const options = {
  //   method: "GET",
  //   // data: data,
  //   headers: {
  //     "content-Type": "application/json",
  //     Authorization: `Basic ${token}`,
  //   },
  // };
});

app.post("/crmcontact", async (req, res) => {
  let user_id = req.body.detail.id;
  let eventType = req.body.type;

  console.log(req.body);
  const email = req.headers.email;
  const apiKey = req.headers.token;
  const credentials = `${email}/token:${apiKey}`;

  let client = zendesk.createClient({
    username: email,
    token: apiKey,
    subdomain: req.headers.domain,
  });
  let apps = await client.installations.list();

  const myApp = apps.filter(
    (values) => values.settings.name === "Zendesk zohoCRM sync"
  );

  const appId = myApp[0].app_id;
  // const appInstallations = await client.apps.list();
  // console.log(appInstallations);
  const token = Buffer.from(credentials).toString("base64");
  // const appId = await getAppid(req);
  await getDataFromDb(appId);
  //console.log(await client.users.get(user_id));
  //res.send("success");
  const url = `https://${req.headers.domain}.zendesk.com/api/v2/users/${user_id}.json`;
  console.log(url);

  let config = {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Basic ${token}`,
    },
  };
  axios
    .get(url, config)
    .then(function (response) {
      const zen_details = response.data.user;
      console.log(zen_details);
      let crm_details = [];
      let obj = {};
      const userName = zen_details.name;
      const mapped_fields = JSON.parse(zohoCredentials.fields);
      mapped_fields.map((element) => {
        if (
          element.zen_is_cf === "true" &&
          zen_details["user_fields"][element.zen_fields] != undefined &&
          zen_details["user_fields"][element.zen_fields] != ""
        ) {
          let zenFieldValue = zen_details["user_fields"][element.zen_fields];
          zenFieldValue =
            element.crm_field_type === "date"
              ? zenFieldValue.split("T")[0]
              : zenFieldValue;
          obj[element.CRM_fields] = zenFieldValue;
        } else if (
          zen_details[element.zen_fields] != undefined &&
          zen_details[element.zen_fields] != ""
        ) {
          obj[element.CRM_fields] = zen_details[element.zen_fields];
        }
      });
      crm_details.push(obj);
      if (eventType === "zen:event-type:user.created") {
        console.log("create event");
        createContactInCRM(crm_details, req, res, { user_id, userName });
      } else {
        updateContactInCRM(crm_details, req, res, user_id);
      }
    })
    .catch(function (error) {
      console.log(error);
      res.status(500).send(error.message);
    });
});
const refreshAccessToken = (from, req, res, crm_details, user_id) => {
  let dc = zohoCredentials.domain.split(".")[2];

  let url = `https://accounts.zoho.${dc}/oauth/v2/token?client_id=${zohoCredentials.clientId}&grant_type=refresh_token&client_secret=${zohoCredentials.clientSecret}&refresh_token=${zohoCredentials.refreshToken}`;

  axios
    .post(url, {
      method: "POST",
    })
    .then((response) => {
      //console.log(response.data);
      zohoCredentials.accessToken = response.data.access_token;
      if (db == null) db = helpers.getConnection();
      db.query(
        constants.ZEN_UPDATE_TOKEN,
        [response.data.access_token, zohoCredentials.appId],
        function (err) {
          if (err) {
            return console.error(err.message);
          } else {
            //console.log(zohoCredentials.accessToken);
            if (from === "fields") {
              getCRMfields(req, res);
            } else if (from === "update") {
              updateContactInCRM(crm_details, req, res, user_id);
            } else if (from === "create") {
              createContactInCRM(crm_details, req, res, user_id);
            }
          }
        }
      );
    })
    .catch((er) => console.error("ERROR : " + er));
};

const getCRMfields = async (req, res) => {
  try {
    let url = `${zohoCredentials.domain}/crm/v2/settings/fields?module=contacts&type=unused`;
    const options = {
      method: "GET",
      headers: {
        Authorization: `Zoho-oauthtoken ${zohoCredentials.accessToken}`,
      },
      contentType: "application/json",
    };

    const response = await axios.get(url, options);
    if (response.status === 200) {
      res.status(200).send({ data: response.data, code: "SUCCESS" });
    } else {
      res.status(200).send({ data: "failed", code: "FAILED" });
    }
  } catch (er) {
    console.error(er);
    if (er.response?.data?.code === "INVALID_TOKEN") {
      refreshAccessToken("fields", req, res);
    } else {
      res.status(200).send({ data: "failed", code: "FAILED" });
    }
  }
};
const createContactInCRM = async (details, req, res, { user_id, userName }) => {
  console.log("create contact");

  const saveFailedContacts = (failedContacts) => {
    const jsonString = JSON.stringify(failedContacts);
    if (db == null) db = helpers.getConnection();
    db.query(
      constants.ZEN_UPDATE_FAILEDCONTACTS,
      [jsonString, zohoCredentials.appId],
      function (err) {
        if (err) {
          console.error(err.message);
        } else {
          console.log(`Failed contacts row updated`);
        }
      }
    );
  };

  const saveSuccessfulContacts = (createdContacts) => {
    const jsonString = JSON.stringify(createdContacts);
    if (db == null) db = helpers.getConnection();
    db.query(
      constants.ZEN_UPDATE_SUCCESSFULCONTACTS,
      [jsonString, zohoCredentials.appId],
      function (err) {
        if (err) {
          console.error(err.message);
        } else {
          zohoCredentials.successfulContacts = JSON.stringify(createdContacts);
          console.log(`Successful contacts row updated `);
        }
      }
    );
  };

  try {
    const contactData = {
      data: details,
    };
    let url = `${zohoCredentials.domain}/crm/v2/Contacts`;
    const options = {
      headers: {
        Authorization: `Zoho-oauthtoken ${zohoCredentials.accessToken}`,
        "Content-Type": "application/json",
      },
    };
    const response = await axios.post(url, contactData, options);
    console.log(response.data);
    let jsonString = JSON.stringify(response.data);
    jsonString = JSON.parse(jsonString);
    const payload = jsonString.data[0];

    if (payload.code === "SUCCESS") {
      let crm_contact_id = payload.details.id;
      let createdContacts = [];
      if (!zohoCredentials.successfulContacts) {
        createdContacts.push({ zen_contact_id: user_id, crm_contact_id });
      } else {
        createdContacts = JSON.parse(
          zohoCredentials.successfulContacts || "[]"
        );
        createdContacts.push({ zen_contact_id: user_id, crm_contact_id });
      }
      console.log({ zen_contact_id: user_id, crm_contact_id });
      console.log(createdContacts);

      saveSuccessfulContacts(createdContacts);
      res
        .status(200)
        .send({ message: "contact created successfully", body: response.data });
    } else {
      let failedContacts = [];

      if (!zohoCredentials.failedContacts) {
        failedContacts.push({ userName, user_id, message: payload.code });
      } else {
        failedContacts = JSON.parse(zohoCredentials.failedContacts || "[]");
        failedContacts.push({ userName, user_id, message: payload.code });
      }
      saveFailedContacts(failedContacts);
      res
        .status(200)
        .send({ message: "contact creation failed", message: payload.code });
    }
  } catch (er) {
    console.error(er);
    if (er.response?.data?.code === "INVALID_TOKEN") {
      refreshAccessToken("create", req, res, details, user_id);
    } else {
      res.status(200).send({ message: "something went wrong" });
    }
  }

  // const apiUrl = `${zohoCredentials.domain}/crm/v2/Contacts`;
  // console.log(zohoCredentials.accessToken);
  // const contactData = {
  //   data: [
  //     {
  //       Last_Name: name,
  //       Email: email,
  //     },
  //   ],
  // };
  // const config = {
  //   method: "GET",
  //   headers: {
  //     Authorization: `Zoho-oauthtoken ${zohoCredentials.accessToken}`,
  //     "Content-Type": "application/json",
  //   },

  //   // body: JSON.stringify(contactData),
  // };
  // console.log(config);
  // console.log(apiUrl);
  // axios
  //   .post(apiUrl, config)
  //   .then((response) => response.json())
  //   .then((data) => {
  //     console.log("Contact created successfully:", data);
  //   })
  //   .catch((error) => {
  //     console.error("Error creating contact:", error.response.data);
  //   });
};
const updateContactInCRM = async (crm_details, req, res, user_id) => {
  // console.log(zohoCredentials.successfullContacts);
  console.log("updated contact");

  let createdContacts = [];
  console.log("zohocredential up", zohoCredentials);

  if (zohoCredentials.successfulContacts != null) {
    createdContacts = [...JSON.parse(zohoCredentials.successfulContacts)];
  }
  // console.log(createdContacts);

  const filteredContact = createdContacts.filter((values) => {
    // console.log(`${user_id}` === values.zen_contact_id);
    return `${user_id}` === values.zen_contact_id;
  });

  console.log("filter", filteredContact);
  if (filteredContact.length > 0) {
    crm_details[0].id = filteredContact[0].crm_contact_id;
    // console.log(crm_details);
    try {
      const contactData = {
        data: crm_details,
      };
      // let url = "https://www.zohoapis.com/crm/v5/Contacts";
      let url = `${zohoCredentials.domain}/crm/v2/Contacts`;
      const options = {
        headers: {
          Authorization: `Zoho-oauthtoken ${zohoCredentials.accessToken}`,
          "content-Type": "application/json",
        },

        // body: JSON.stringify(contactData),
      };
      // console.log(options);
      const response = await axios.put(url, contactData, options);
      console.log(response.data);
      // console.log(JSON.parse(response.data.body));
      let jsonString = JSON.stringify(response.data);
      jsonString = JSON.parse(jsonString);
      // console.log(jsonString.data[0]);
      const payload = jsonString.data[0];
      res
        .status(200)
        .send({ message: "contact updated successfully", body: response.data });
    } catch (er) {
      console.error(er);

      if (er.response?.data?.code === "INVALID_TOKEN") {
        refreshAccessToken("update", req, res, crm_details, user_id);
      } else {
        res.status(200).send({ message: "something went wrong" });
      }
    }
  } else {
    createContactInCRM(crm_details, req, res, user_id);
  }
};
app.post("/deleteAppData", (req, res) => {
  const { appId } = req.body;

  let sql = "DELETE FROM zoho WHERE appId=?";
  db.query(sql, appId, function (err, result) {
    if (err) {
      console.error(err);
      res.status(500).json({ message: er });
    } else {
      console.log("Table row  deleted " + appId);
      res.status(200).json({ message: "Row has been deleted " + appId });
    }
  });
});

// app.post("/incomingsms", async (req, res) => {
//   console.log(req.body.Body);
//   const twiml = new MessagingResponse();
//   twiml.message("Ticket created successfully");

//   res.type("text/xml").send(twiml.toString());
// });

const getDataFromDb = async (appId) => {
  return new Promise((resolve, reject) => {
    const query = `SELECT * FROM zoho WHERE appId = ?`;
    db.query(query, [appId], (err, results) => {
      if (err) {
        console.error("Database error:", err);
        resolve({ authentication: false });
      } else if (results.length === 0) {
        console.log("No results found.");
        resolve({ authentication: false });
      } else {
        const row = results[0];
        zohoCredentials = { ...row };
        resolve({
          authentication: true,
          mapped_fields: zohoCredentials.fields,
        });
      }
    });
  });
};

// app.post("/registerDataTwilio", (req, res) => {
//   console.log(`Data to register: ${JSON.stringify(req.body)}`);
//   const { name, email, password } = req.body;
//   //  {
//   //   name: "twiloi",
//   //   email: "twiloi@example.com",
//   //   password: "twilo1234",
//   // };
//   const id = uuidv4();
//   const numericId = parseInt(id.replace(/-/g, "").slice(0, 6), 16);
//   const formattedId = ("000000" + numericId).slice(-6);
//   const query =
//     "INSERT INTO Twilio (id, name, email, password) VALUES (?, ?, ?, ?)";
//   db.query(query, [formattedId, name, email, password], (err) => {
//     if (err) {
//       console.error(JSON.stringify(err));
//       res.json({
//         data: `User ${name} registration failed. \n Error ${err} `,
//       });
//     } else {
//       console.log("Successfully data stored in the table");
//       res.json({
//         data: `User ${name} registered successfully with ID: ${formattedId}`,
//       });
//     }
//   });
// });

// app.post("/signin", (req, res) => {
//   console.log(req.body);
//   // res.status(200).json({ data: `User signed in successfully` });
//   const { id, email, password } = {
//     id: "496852",
//     email: "twiloi@example.com",
//     password: "twilo1234",
//   };
//   const query = `SELECT * FROM twilio WHERE id=${id}`;

//   db.query(query, [email, password], (err, results) => {
//     console.log(results);
//     if (err) {
//       console.error(JSON.stringify(err.sqlmessage));
//       res.json({ data: `Sign-in failed.  ${err}` });
//     } else if (results.length > 0) {
//       if (results[0].email === email && results[0].password === password) {
//         console.log("Sign-in successful");
//       } else if (results[0].email !== email) {
//         console.log("Sign-in Unsuccessful. Invalid email address");
//       } else if (results[0].password !== password) {
//         console.log("Sign-in Unsuccessful. Invalid password");
//       }
//       res.json({ data: `User ${email} signed in successfully` });
//     } else {
//       console.log("Sign-in failed. Invalid credentials.");
//       res.json({ data: `Sign-in failed. Invalid email or password.` });
//     }
//   });
// });

// let otps = {};

// const generateOTP = () => {
//   return crypto.randomInt(100000, 999999).toString();
// };

// const transporter = nodemailer.createTransport({
//   service: "gmail",
//   auth: {
//     user: constants.EMAIL_CONFIG.email,
//     pass: constants.EMAIL_CONFIG.password,
//   },
// });

// const sendEmail = (to, subject, text) => {
//   const mailOptions = {
//     from: {
//       name: "Tamilarasi Athinarayanan",
//       address: emailConfig.email,
//     },
//     to: "tamilarasi@gmail.com",
//     subject,
//     text,
//   };
//   console.log(mailOptions);
//   return transporter.sendMail(mailOptions);
// };

// app.post("/forgot-password", (req, res) => {
//   const { email } = { email: "tamilarasi@gmail.com" };
//   const otp = generateOTP();
//   const expiry = Date.now() + constants.OTP_EXPIRY_TIME;
//   otps[email] = { otp, expiry };
//   sendEmail(email, "Your OTP for Email Verification", `Your OTP is ${otp}`)
//     .then(() => {
//       console.log("OTP sent to your email");
//       res.status(200).send("OTP sent to your email");
//     })
//     .catch((error) => {
//       res.status(500).send("Error sending OTP");
//       console.error("Error sending OTP : ", error.response);
//     });
// });

// app.post("/verify-otp", (req, res) => {
//   const { email, otp } = req.body;

//   if (!otps[email]) {
//     return res.status(400).send("Invalid email or OTP");
//   }

//   const { otp: storedOtp, expiry } = otps[email];

//   if (Date.now() > expiry) {
//     delete otps[email];
//     return res.status(400).send("OTP expired");
//   }

//   if (otp !== storedOtp) {
//     return res.status(400).send("Invalid OTP");
//   }

//   delete otps[email];
//   res.status(200).send("OTP verified. You can now reset your password");
// });

// app.post("/reset-password", (req, res) => {
//   const { id, email, newPassword } = {
//     id: "011713",
//     email: "****@gmail.com",
//     newPassword: "new password",
//   };
//   db.query(
//     `UPDATE Twilio SET password = ${newPassword},email=${email} WHERE id= ${id}`,
//     (err, results) => {
//       if (err) {
//         console.error(err.sqlmessage);
//       } else {
//         console.log("password updated successfully", results);
//       }
//     }
//   );
//   res.status(200).send("Password reset successfully");
// });

//Twilio
// app.post("/upload", upload.array("twilio", 5), (req, res) => {
// console.log(req.body);

// console.log(req.files);
// res.sendStatus(200);

// if (!req.files || req.files.length === 0) {
//   return res.status(400).json({ error: "No files were uploaded." });
// }

// const folders = {
//   images: "uploadfile/images",
//   videos: "uploadfile/videos",
//   audios: "uploadfile/audios",
// };

// const fileMappings = {
//   ".jpg": folders.images,
//   ".jpeg": folders.images,
//   ".png": folders.images,
//   ".gif": folders.images,
//   ".mp4": folders.videos,
//   ".mp3": folders.audios,
// };

// try {
//   const filePaths = req.files.map((file) => {
//     const extension = path.extname(file.originalname).toLowerCase();
//     const folder = fileMappings[extension];

//     if (!folder) {
//       throw new Error(`Unsupported file type: ${file.originalname}`);
//     }

//     if (!fs.existsSync(folder)) {
//       fs.mkdirSync(folder, { recursive: true });
//     }

//     const sanitizedFileName = file.originalname.replace(/\s+/g, "-");
//     const filePath = path.join(folder, sanitizedFileName);
//     fs.renameSync(file.path, filePath);
//     return `https://api.vtecknologies.com/${filePath}`;
//   });

//   res.status(200).json({
//     message: "Files uploaded successfully.",
//     files: filePaths,
//   });
// } catch (error) {
//   res.status(400).json({ error: error.message });
// }
// });

//twilio
// app.get("/uploadfile/:type/:fileName", (req, res) => {
//   console.log(req.params.type);
//   console.log(req.params.fileName);
//   const fileType = req.params.type;
//   console.log(fileType);

//   const fileName = req.params.fileName;

//   // Determine the folder based on the file type (images or videos)
//   const validFileTypes = ["images", "videos", "audios"];
//   if (!validFileTypes.includes(fileType)) {
//     return res.status(400).send("Invalid file type requested.");
//   }

//   const folderPath = path.join(__dirname, "uploadfile", fileType);
//   const filePath = path.join(folderPath, fileName);

//   console.log(fileName); // Outputs the file name
//   console.log(filePath); // Outputs the full file path

//   // Send the file as a response
//   res.sendFile(filePath, (err) => {
//     if (err) {
//       res.status(500).send("Error sending the file.");
//     }
//   });
// });

// app.get("/uploads/:accountId/:fileName", (req, res) => {
//   const { accountId, fileName } = req.params;
//   const BASE_DIR = path.join(__dirname, "../uploads");
//   const filePath = path.join(BASE_DIR, accountId, fileName);

//   if (fs.existsSync(filePath)) {
//     res.sendFile(filePath);
//   } else {
//     res.status(404).json({ error: "File not found" });
//   }
// });

// module.exports = {
//   sendEmail,
// };

// const fs = require('fs');

// app.use(express.raw({ type: '*/*', limit: '10mb' }));
// const isImage = (ext) => ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp'].includes(ext);
// const isVideo = (ext) => ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.mkv', '.webm', '.m4v'].includes(ext);
// app.post('/upload', (req, res) => {
//     const contentType = req.headers['content-type'];
//     const extension = contentType.split('/')[1];

//     let folder;
//     if (isImage(`.${extension}`)) {
//         folder = 'uploadfiles/images';
//     } else if (isVideo(`.${extension}`)) {
//         folder = 'uploadfiles/videos';
//     } else {
//         return res.status(400).send('File type is neither image nor video.');
//     }
//     if (!fs.existsSync('uploadfiles')) {
//         fs.mkdirSync('uploadfiles');
//     }
//     if (!fs.existsSync(folder)) {
//         fs.mkdirSync(folder);
//     }

//     const fileName = `file_${Date.now()}.${extension}`;
//     const filePath = path.join(__dirname, folder, fileName);
//     fs.writeFile(filePath, req.body, (err) => {
//         if (err) {
//             return res.status(500).send('Error saving the file.');
//         }

//   console.log(`Received Content-Type: ${contentType}`);
//   console.log(`File extension: ${extension}`);
//   console.log(fileName);
//         res.send(`File ${fileName} uploaded successfully!`);
//     });
// });

// const multer = require('multer');
// const fs = require('fs');
// const upload = multer({ dest: 'uploadfile/' });

// app.post('/upload', upload.single('file'), (req, res) => {
//     if (!req.file) {
//         return res.status(400).send('File cannot be upload.');
//     }

//     const extension = path.extname(req.file.originalname).toLowerCase();
//     let folder;

//     const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif'];
//     const videoExtensions = ['.mp4', '.avi'];

//     if (imageExtensions.includes(extension)) {
//         folder = 'uploadfile/images';
//     } else if (videoExtensions.includes(extension)) {
//         folder = 'uploadfile/videos';
//     } else {
//         return res.status(400).send('Unsupported file type.');
//     }

//     if (!fs.existsSync(folder)) {
//         fs.mkdirSync(folder, { recursive: true });
//     }

//     const filePath = path.join(folder, req.file.filename + extension);
//     fs.rename(req.file.path, filePath, (err) => {
//         if (err) {
//             return res.status(500).send('Error saving the file.');
//         }
//         res.send(`File uploaded successfully: ${filePath}`);
//     });
// });

app.post("/deleteCrmcontact", async (req, res) => {
  console.log("delete webhook");

  let user_id = req.body.detail.id;
  let eventType = req.body.type;
  console.log(eventType);

  const email = req.headers.email;
  const apiKey = req.headers.token;
  // const credentials = `${email}/token:${apiKey}`;

  let client = zendesk.createClient({
    username: email,
    token: apiKey,
    subdomain: req.headers.domain,
  });
  let apps = await client.installations.list();

  const myApp = apps.filter(
    (values) => values.settings.name === "Zendesk zohoCRM sync"
  );

  const appId = myApp[0].app_id;
  await getDataFromDb(appId);
  // const token = Buffer.from(credentials).toString("base64");

  // if (eventType === "zen:event-type:user.deleted") {
  // console.log("delete event");

  // const url = `https://${req.headers.domain}.zendesk.com/api/v2/users/${user_id}.json`;
  // let config = {
  //   method: "GET",
  //   headers: {
  //     "Content-Type": "application/json",
  //     Authorization: `Basic ${token}`,
  //   },
  // };

  try {
    // const response = await axios.get(url, config);
    // const zen_details = response.data.user;
    // console.log(zen_details);
    await deleteContactFromCRM(req, res, user_id);
    // res.status(200).send({ message: "Contact deleted successfully", body: response.data });
  } catch (error) {
    console.log(error);
    res.end(error.message);
    res
      .status(500)
      .send({ message: "Failed to delete contact", error: error.message });
  }
  // } else {
  // res.status(200).send({ message: "No delete event detected"
  // });
  // }
});

const deleteContactFromCRM = async (req, res, user_id) => {
  console.log("delete contact");
  const saveSuccessfulDeletes = (deletedContacts) => {
    const jsonString = JSON.stringify(deletedContacts);
    if (db == null) db = helpers.getConnection();
    db.query(
      constants.ZEN_UPDATE_SUCCESSFULCONTACTS,
      [jsonString, zohoCredentials.appId],
      function (err) {
        if (err) {
          console.error(err.message);
        } else {
          zohoCredentials.successfulContacts = JSON.stringify(deletedContacts);
          console.log(`Contact deleted successfully`);
        }
      }
    );
  };

  let contact = [];
  console.log("zoho cre", zohoCredentials);
  if (zohoCredentials.successfulContacts != null) {
    contact = [...JSON.parse(zohoCredentials.successfulContacts)];
  }
  let savedContacts = [];
  console.log(contact);

  const deletedContact = contact.filter((value) => {
    console.log(value.zen_contact_id === `${user_id}`);

    if (value.zen_contact_id === `${user_id}`) {
      return value;
    } else {
      savedContacts.push(value);
    }
  });

  if (deletedContact.length > 0) {
    try {
      let url = `${zohoCredentials.domain}/crm/v2/Contacts/${deletedContact[0].crm_contact_id}`;
      const options = {
        headers: {
          Authorization: `Zoho-oauthtoken ${zohoCredentials.accessToken}`,
          "Content-Type": "application/json",
        },
      };

      const response = await axios.delete(url, options);
      console.log(url, response.data);

      let jsonString = JSON.stringify(response.data);
      jsonString = JSON.parse(jsonString);
      const payload = jsonString.data[0];

      if (payload.code === "SUCCESS") {
        saveSuccessfulDeletes(savedContacts);
        res.status(200).send({
          message: "Contact deleted successfully",
          body: response.data,
        });
      } else {
        res
          .status(500)
          .send({ message: "Contact deletion failed", error: payload.code });
      }
    } catch (er) {
      console.error(er);
      if (er.response?.data?.code === "INVALID_TOKEN") {
        refreshAccessToken("delete", req, res, user_id);
      } else {
        res
          .status(500)
          .send({ message: "Something went wrong", error: er.message });
      }
    }
  } else {
    console.log("Zendesk contact does not match in Zoho CRM contact");
    res
      .status(404)
      .send({ message: "Zendesk contact does not match in Zoho CRM contact" });
  }
};

app.get("/approval", (req, res) => {
  fdUrl = req.query.url;
  fdTicketId = req.query.ticket;
  res.sendFile(path.join(__dirname, "app", `approval.html`));
});

app.get("/approvalData", async (req, res) => {
  db === null ? helpers.getConnection() : "";
  const email = req.query.email;
  const ticketId = req.query.ticketId;
  const approveAppId = req.query.appid;
  const requestId = req.query.requestId;

  const query =
    "SELECT * FROM Approval WHERE email = ? AND ticketId = ? AND appId=?";
  db.query(
    query,
    [email, ticketId, approveAppId, requestId],
    (err, results) => {
      if (err) {
        console.error("Database error:", err);
        res.status(500).json({ error: "Internal Server Error" });
      } else {
        console.log(results);
        res.status(200).json(results);
      }
    }
  );
});

app.get("/updateApprovalData", async (req, res) => {
  const email = req.query.email;
  const ticketId = req.query.ticketId;
  const status = req.query.status;
  const name = req.query.name;
  const formattedDate = req.query.date;
  const approveAppId = req.query.appid;
  const requestId = req.query.requestId;

  const id = uuidv4();
  const numericId = parseInt(id.replace(/-/g, "").slice(0, 6), 16);
  const formattedId = ("000000" + numericId).slice(-6);
  const query = `INSERT INTO Approval (id, name, email, status, ticketId, appId, requestId, date) VALUES (?, ?, ?, ?, ?, ?,?,?)`;

  db.query(
    query,
    [
      formattedId,
      name,
      email,
      status,
      ticketId,
      approveAppId,
      requestId,
      formattedDate,
    ],
    (err, results) => {
      if (err) {
        console.error("Database error:", err);
        res.status(500).send("Database error");
      } else {
        console.log("updated approval");
        res.status(200).json({ message: "Data updated successfully", results });
      }
    }
  );
});

app.post("/externalApproval", async (req, res) => {
  console.log(req);

  try {
    const url = req.body.url;
    let data = req.body.data;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`Network response was not ok: ${response.statusText}`);
    }

    const responseData = await response.json();
    console.log("Success:", responseData);
    res.status(200).json({ message: "success", data: responseData });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "error", error: error.message });
  }
});

app.delete("/deleteApprovalData", async (req, res) => {
  try {
    const email = req.query.email;
    const ticketId = req.query.ticketId;
    const approveAppId = req.query.appid;
    console.log(req.query);

    const query = `DELETE FROM Approval WHERE email = ? AND ticketId = ? AND appId = ?`;

    db.query(query, [email, ticketId, approveAppId], (err, results) => {
      if (err) {
        console.error("Database error:", err);
        res.status(500).send("Database error");
      } else if (results.affectedRows === 0) {
        console.log("No record found to delete");
        res.status(404).json({ message: "No record found to delete" });
      } else {
        console.log("Deleted approval");
        res.status(200).json({ message: "Data deleted successfully", results });
      }
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "error", error: error.message });
  }
});

app.get("/qbMonday", (req, res) => {
  console.log("qbmonday");
  res.sendFile(
    path.join(__dirname, "app", "QB_Monday", "quickBookMonday.html")
  );
});

app.post("/web", function (req, res) {
  console.log(JSON.stringify(req.body, 0, 2));
  res.status(200).send(req.body);
});
