// const sqlite3 = require("sqlite3").verbose();

// exports.getConnection = () => {
//   const db = new sqlite3.Database(
//     "./data.db",
//     sqlite3.OPEN_READWRITE,
//     (err) => {
//       if (err) return console.error(JSON.stringify(err));
//     }
//   );
//   return db;
// };

// exports.getZenConnection = () => {
//   const zenDb = new sqlite3.Database(
//     "./zen-data.db",
//     sqlite3.OPEN_READWRITE,
//     (err) => {
//       if (err) return console.error(JSON.stringify(err));
//       console.log("db connected");
//     }
//   );
//   return zenDb;
// };
// helpers.js

const mysql = require("mysql");
const fs = require("fs");
const util = require("util");
const path = require("path");
const constants = require("./constant");

const mysqlConfig = {
  host: "127.0.0.1",
  user: "root",
  password: "Vteck@12",
  database: "vteckdb",
  port: 3306,
};

const logDir = "errorHandling";
const logFilePath = path.join(logDir, "error.log");
const maxLogFileSize = 5 * 1024 * 1024;

if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}

const checkLogFileSize = async () => {
  try {
    const stats = await util.promisify(fs.stat)(logFilePath);
    if (stats.size >= maxLogFileSize) {
      const timestamp = new Date().toISOString().replace(/[-:.]/g, "");
      const newLogFilePath = path.join(
        logDir,
        `${path.basename(logFilePath, ".log")}_${timestamp}.log`
      );
      await util.promisify(fs.rename)(logFilePath, newLogFilePath);
    }
  } catch (err) {
    if (err.code !== "ENOENT") {
      console.error("Failed to check log file size:", err);
    }
  }
};

const log = async (message) => {
  await checkLogFileSize();
  const logFile = fs.createWriteStream(logFilePath, { flags: "a" });
  const logMessage = `${new Date().toISOString()} - ${message}\n`;
  await util.promisify(logFile.write).bind(logFile)(logMessage);
  logFile.end();
};

exports.getConnection = () => {
  const connection = mysql.createConnection(mysqlConfig);
  connection.connect(async (err) => {
    if (err) {
      await log(JSON.stringify(err));
      if (err.sqlMessage)
        console.error("error :", JSON.stringify(err.sqlMessage));
      else console.error("error", JSON.stringify(err));
    } else {
      console.log("Connected to MySQL as id", connection.threadId);

      connection.query(constants.CREATE_APPROVALAPP_TABLE, (err) => {
        if (err) {
          console.error("Failed to create Approval table:", err);
        } else {
          console.log("Approval table created or already exists");
        }
      });

      connection.query(constants.CREATE_QBMONDAY_TABLE, (err) => {
        if (err) {
          console.error("Failed to create qb table:", err);
        } else {
          console.log("qb table created or already exists");
        }
      });

    }
  });

  return connection;
};

exports.getZenConnection = () => {
  const otherConnection = mysql.createConnection(mysqlConfig);
  otherConnection.connect(async (err) => {
    if (err) {
      await log(JSON.stringify(err));
      if (err.sqlMessage)
        console.error("error", JSON.stringify(err.sqlMessage));
      else console.error("error", JSON.stringify(err));
    } else {
      console.log("Connected to MySQL as id", otherConnection.threadId);
    }
  });
  return otherConnection;
};
