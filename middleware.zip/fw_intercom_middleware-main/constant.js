module.exports = {
  GREETINGS: "Hey, I'm middleware, listening to you.",
  URL_NOT_REGISTERED: "URL not registered with the middleware",
  MSG: "Received data sent to the URL",
  ERROR_MSG: "Error occurred",
  CREATE_QUERY:
    "CREATE TABLE IF NOT EXISTS users (id VARCHAR(255) PRIMARY KEY, url TEXT, app TEXT, isactive INT DEFAULT 1);",
  INSERT_URL: "INSERT INTO users (id, url, app) VALUES (?, ?, ?);",
  ZEN_CREATE_QUERY:
    "CREATE TABLE IF NOT EXISTS zoho (appId VARCHAR(255) PRIMARY KEY, clientId VARCHAR(255), clientSecret VARCHAR(255), refreshToken TEXT, accessToken TEXT, domain TEXT, fields TEXT, failedContacts TEXT, successfulContacts TEXT);",
  ZEN_INSERT_URL:
    "INSERT INTO zoho (appId, clientId, clientSecret, refreshToken, accessToken, domain) VALUES (?, ?, ?, ?, ?, ?);",
  ZEN_UPDATE_TOKEN: "UPDATE zoho SET accessToken = ? WHERE appId = ?;",
  ZEN_UPDATE_FIELDS: "UPDATE zoho SET fields = ? WHERE appId = ?;",
  ZEN_UPDATE_FAILEDCONTACTS:
    "UPDATE zoho SET failedContacts = ? WHERE appId = ?;",
  ZEN_UPDATE_SUCCESSFULCONTACTS:
    "UPDATE zoho SET successfulContacts = ? WHERE appId = ?;",
  CREATE_APPROVALAPP_TABLE:
    "CREATE TABLE IF NOT EXISTS Approval (id VARCHAR(36) PRIMARY KEY,name VARCHAR(100), email VARCHAR(100),status VARCHAR(50),  ticketId VARCHAR(100),appId VARCHAR(50),requestId VARCHAR(50),date VARCHAR(50))",
  CREATE_QBMONDAY_TABLE:
   "CREATE TABLE IF NOT EXISTS quickbook_Monday (realmId VARCHAR(50) PRIMARY KEY,account VARCHAR(50),qbAccessToken TEXT, qbRefreshToken TEXT, mondayAccessToken TEXT, mondayInvoiceBoardId VARCHAR(100), mondayCustomerBoardId VARCHAR(100), subitemBoardId VARCHAR(100),sandboxOrProduction VARCHAR(50))",
  CREATE_QBMONDAY_DATA_TABLE:
  "CREATE TABLE IF NOT EXISTS quickbookMonday_Data (id INT AUTO_INCREMENT PRIMARY KEY, realmId VARCHAR(100), boardId VARCHAR(100), qbInvoiceId VARCHAR(100), mondayInvoiceId VARCHAR(100), qbCustomerId VARCHAR(100), mondayCustomerId VARCHAR(100), updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)",
  
  TWILIO: {
    TW_CREATE:
      "CREATE TABLE IF NOT EXISTS twilio_messages (id INT PRIMARY KEY AUTO_INCREMENT,account_id VARCHAR(255) NOT NULL,ticket_id VARCHAR(255) NOT NULL,message TEXT NOT NULL,sender TEXT NOT NULL,media_urls TEXT DEFAULT NULL,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,INDEX idx_account_ticket (account_id, ticket_id))",
    TW_INDEX_CREATE:
      "CREATE INDEX idx_account_ticket ON twilio_messages (account_id, ticket_id)",
    TW_INSERT:
      "INSERT INTO twilio_messages (account_id, ticket_id, message, sender, media_urls) VALUES (?, ?, ?, ?, ?)",
    TW_GET:
      "SELECT id, message, sender, created_at, COALESCE(media_urls, '[]') AS media_urls FROM twilio_messages WHERE account_id = ? AND ticket_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?",
    TW_TICKET_DELETE:
      "DELETE FROM twilio_messages WHERE account_id = ? AND ticket_id = ?",
    TW_ACCOUNT_DELETE: "DELETE FROM twilio_messages WHERE account_id = ?",
  },
  EMAIL_CONFIG: {
    service: "gmail",
    host: "smtp.gmail.com",
    email: "*****@gmail.com",
    password: "", 
  },
  OTP_EXPIRY_TIME: 300000,
};
