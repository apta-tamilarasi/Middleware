# fw_intercom_middleware
Middleware between Freshsales and Intercom to pass the data.
