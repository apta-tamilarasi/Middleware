const getDefaultZenFields = () => {
  return [
    { title: "Name", key: "name", type: "Text", cf: true },
    { title: "Email", key: "email", type: "Email", cf: true },
    { title: "Twitter", key: "twitter", type: "Text", cf: true },
    { title: "Details", key: "details", type: "Text", cf: true },
    { title: "Notes", key: "notes", type: "Text", cf: true },
    { title: "Role", key: "role", type: "Dropdown", cf: true },
  ];
};

const getCrmDataTypeList = () => [
  "profileimage",
  "ownerlookup",
  "fileupload",
  "contactimage",
  "currency",
  "multiselectpicklist",
  "percentage",
  "formula",
];
const getCrmApiNameList = () => [
  "First_Name",
  "Tag",
  "Modified_Time",
  "Last_Activity_Time",
  "Unsubscribed_Mode",
  "Last_Enriched_Time__s",
  "Enrich_Status__s",
  "Change_Log_Time__s",
  "Locked__s",
  "Created_Time",
  "Unsubscribed_Time",
  "Salutation",
  "Full_Name",
];

const getNumberTypes = () => [
  "double",
  "bigint",
  "phone",
  "currency",
  "double",
  "autonumber",
];
