
const express = require("express");
const router = express.Router();
const axios = require("axios");
const constants = require("../../constant");
const helpers = require("../../helpers");
let db = helpers.getConnection();
require('dotenv').config(); 
const cors = require("cors");



let clientId = "ABf8UxfBd0oVXI9w6kj5asssksK84JcYj03J2muxcmfepTFOAx";
let clientSecret = "5hiiI3wuSh4QBozTItpyFKxp0C7ulpiqbSoJ8Ij1";

let mondayApiKey = "";
let sandboxProduction=""

router.use(
    cors({
        origin: "http://localhost:3000",
        methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    })
);


router.get("/", (req, res) => {
    res.send("<p>Hello Quick Book and Monday.com Integration</p>");


});

async function getTokens(realmId) {
    return new Promise((resolve, reject) => {
        db.query("SELECT qbAccessToken, qbRefreshToken, mondayAccessToken, mondayInvoiceBoardId , mondayCustomerBoardId, subitemBoardId,sandboxOrProduction FROM quickbook_Monday WHERE realmId = ?", [realmId], (err, results) => {
            if (err) {
                return reject(err);
            }
            resolve(results.length ? results[0] : null);
        });
    });
}

async function updateTokens(realmId, qbAccessToken, qbRefreshToken) {
    return new Promise((resolve, reject) => {
        db.query("UPDATE quickbook_Monday SET qbAccessToken = ?, qbRefreshToken = ? WHERE realmId = ?",
            [qbAccessToken, qbRefreshToken, realmId], (err) => {
                if (err) {
                    return reject(err);
                }
                resolve();
            });
    });
}

router.post("/refreshQbToken", async (req, res) => {
    try {
        const { realmId, refreshToken } = req.body;
        console.log("refreshtoken");


        const response = await axios.post(
            "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer",
            new URLSearchParams({
                grant_type: "refresh_token",
                refresh_token: refreshToken,
            }),
            {
                headers: {
                    "Authorization": `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString("base64")}`,
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "application/json",
                }
            }
        );

        console.log("Token refreshed successfully:", response.data);

        const newAccessToken = response.data.access_token;
        const newRefreshToken = response.data.refresh_token;

        await updateTokens(realmId, newAccessToken, newRefreshToken);

        return res.json({ access_token: newAccessToken, refresh_token: newRefreshToken });
    } catch (error) {
        console.error("Failed to refresh QuickBooks token:", error.response?.data || error.message);

        if (error.response?.data?.error === "invalid_grant") {
            console.error("Refresh token is invalid or expired. You may need to reauthorize.");
            return res.redirect("https://api.vtecknologies.com/qbmonday?reauthorize=true");
        }

        if (!res.headersSent) {
            return res.status(500).json({ error: "Token refresh failed", details: error.response?.data });
        }
    }
});


router.post("/connectQuickbooks", (req, res) => {
    if (req.body.mondaySecret) {
        mondayApiKey = req.body.mondaySecret;
        sandboxProduction=req.body.accountType==="sandbox"?"https://sandbox-quickbooks.api.intuit.com/v3":"https://quickbooks.api.intuit.com/v3"
        console.log(sandboxProduction);
        
    }
    if (!clientId || !clientSecret) {
        return res.status(400).json({ error: "Client ID and Secret are required" });
    }

    const redirectUri = "https://api.vtecknologies.com/mondayqb/callback";
    const authUrl =
        "https://appcenter.intuit.com/connect/oauth2" +
        "?client_id=" + encodeURIComponent(clientId) +
        "&redirect_uri=" + encodeURIComponent(redirectUri) +
        "&scope=com.intuit.quickbooks.accounting" +
        "&response_type=code" +
        "&state=testState";
    res.json({ url: authUrl });
});

async function createMondayInvoiceCustomer(data, apiKeyMonday, mondayBoardId, type, subitemId, operation, details) {
    console.log(`${operation} ${type} in Monday.com...`);
    console.log(data);

    let subitemsId = ''
    try {

        let columnQuery = `query { 
                boards(ids: ${mondayBoardId}) { 
                    columns { id title type } 
                } 
            }`
        let invoiceCustomerColumn = await getMondayDetails(apiKeyMonday, columnQuery);
        invoiceCustomerColumn = invoiceCustomerColumn.boards[0].columns

        if (type === "invoice") {
            if (operation === "Update") {
                let subitem = await getMondayItemDetails(details.mondayInvoiceId, apiKeyMonday)
                subitemsId = subitem.subitems

                if (subitemsId.length > 0) {
                    const deleteMutations = subitemsId.map((subitem, index) =>
                        `delete_item_${index}: delete_item(item_id: ${subitem.id}) { id }`
                    ).join("\n")
                    const query = `mutation { ${deleteMutations} }`;
                    await getMondayDetails(apiKeyMonday, query);
                }
            }

            let invoiceStatusId = 0;

            const invoiceStatusLabels = {
                0: "Unpaid",
                1: "Paid",
                2: "Overdue",
                3: "Partially Paid",
                4: "Partially Paid & Overdue"
            };
            
            const isOverdue = new Date(data.DueDate) < new Date();
            const isPaid = data.Balance === 0;
            const isPartiallyPaid = data.Balance > 0 && data.Balance < data.TotalAmt;
            
            if (isPaid) {
                invoiceStatusId = 1;
            } else if (isOverdue && !isPaid) {
                invoiceStatusId = isPartiallyPaid ? 4 : 2;
            } else if (isPartiallyPaid) {
                invoiceStatusId = 3;
            }
            
            console.log("Invoice Status:", invoiceStatusLabels[invoiceStatusId]);

            let invoiceCol = invoiceCustomerColumn.find(col => col.title === "Invoice #")?.id;
            let customerNameCol = invoiceCustomerColumn.find(col => col.title === "Customer Name")?.id;
            let statusCol = invoiceCustomerColumn.find(col => col.title === "Invoice Status")?.id;
            let dueDateCol = invoiceCustomerColumn.find(col => col.title === "Due Date")?.id;
            let termCol = invoiceCustomerColumn.find(col => col.title === "Term")?.id;
            let totalCol = invoiceCustomerColumn.find(col => col.title === "Total")?.id;
            let balanceDueCol = invoiceCustomerColumn.find(col => col.title === "Balance Due")?.id;
            let emailCol = invoiceCustomerColumn.find(col => col.title === "Email")?.id;
            let addressCol = invoiceCustomerColumn.find(col => col.title === "Address")?.id;
            let subTotalCol = invoiceCustomerColumn.find(col => col.title === "Sub Total")?.id;
            let salesTaxCol = invoiceCustomerColumn.find(col => col.title === "Sales Tax")?.id;
            let creationDateCol = invoiceCustomerColumn.find(col => col.title === "Creation Date")?.id;
            let updatedDateCol = invoiceCustomerColumn.find(col => col.title === "Updated Date")?.id;
            let invoiceLinkCol = invoiceCustomerColumn.find(col => col.title === "Invoice Link")?.id;
            let buttonCol = invoiceCustomerColumn.find(col => col.title === "QB Invoice")?.id;

            let createdDate = data.MetaData.CreateTime.split('T')[0];
            let updatedDate = data.MetaData.LastUpdatedTime.split('T')[0];


            let parentItemQuery = operation === "Create" ? `mutation {
                create_item(                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                    board_id: ${mondayBoardId},
                    item_name: "Invoice ${data.Id || null}",
                    column_values: "{\\"${invoiceCol}\\": ${data.DocNumber || null}, \\"${customerNameCol}\\": ${data.CustomerRef?.name ? `\\"${data.CustomerRef.name}\\"` : null}, \\"${dueDateCol}\\": ${data.DueDate ? `\\"${data.DueDate}\\"` : null}, \\"${termCol}\\": ${data.SalesTermRef?.name ? `\\"${data.SalesTermRef.name}\\"` : null}, \\"${totalCol}\\": ${data.TotalAmt || 0}, \\"${balanceDueCol}\\": ${data.Balance || 0}, \\"${emailCol}\\": ${data.BillEmail?.Address ? `\\"${data.BillEmail.Address}\\"` : null}, \\"${addressCol}\\": ${data.BillAddr ? `\\"${data.BillAddr.Line1 || ''}, ${data.BillAddr.City || ''}, ${data.BillAddr.CountrySubDivisionCode || ''}, ${data.BillAddr.PostalCode || ''}\\"` : null}, \\"${subTotalCol}\\": ${data.Line?.[data.Line.length - 1]?.Amount || 0}, \\"${salesTaxCol}\\": ${data.TxnTaxDetail?.TotalTax || 0}, \\"${creationDateCol}\\": ${createdDate ? `\\"${createdDate}\\"` : null}, \\"${updatedDateCol}\\": ${updatedDate ? `\\"${updatedDate}\\"` : null}, \\"${statusCol}\\": ${invoiceStatusId ? `{\\"index\\": \\"${invoiceStatusId}\\"}` : null}, \\"${invoiceLinkCol}\\": ${data.InvoiceLink ? `\\"${data.InvoiceLink}\\"` : null}}"
                ) {
                    id
                }
            }` : `mutation {
                change_multiple_column_values(
                    board_id: ${mondayBoardId},
                    item_id: ${details.mondayInvoiceId || 0},
                    column_values: "{\\"${invoiceCol}\\": ${data.DocNumber || null}, \\"${customerNameCol}\\": ${data.CustomerRef?.name ? `\\"${data.CustomerRef.name}\\"` : null}, \\"${dueDateCol}\\": ${data.DueDate ? `\\"${data.DueDate}\\"` : null}, \\"${termCol}\\": ${data.SalesTermRef?.name ? `\\"${data.SalesTermRef.name}\\"` : null}, \\"${totalCol}\\": ${data.TotalAmt || 0}, \\"${balanceDueCol}\\": ${data.Balance || 0}, \\"${emailCol}\\": ${data.BillEmail?.Address ? `\\"${data.BillEmail.Address}\\"` : null}, \\"${addressCol}\\": ${data.BillAddr ? `\\"${data.BillAddr.Line1 || ''}, ${data.BillAddr.City || ''}, ${data.BillAddr.CountrySubDivisionCode || ''}, ${data.BillAddr.PostalCode || ''}\\"` : null}, \\"${subTotalCol}\\": ${data.Line?.[data.Line.length - 1]?.Amount || 0}, \\"${salesTaxCol}\\": ${data.TxnTaxDetail?.TotalTax || 0}, \\"${creationDateCol}\\": ${createdDate ? `\\"${createdDate}\\"` : null}, \\"${updatedDateCol}\\": ${updatedDate ? `\\"${updatedDate}\\"` : null}, \\"${statusCol}\\": ${invoiceStatusId ? `{\\"index\\": \\"${invoiceStatusId}\\"}` : null}, \\"${invoiceLinkCol}\\": ${data.InvoiceLink ? `\\"${data.InvoiceLink}\\"` : null}}"
                ) {
                    id
                }
            }`
            
            console.log(parentItemQuery);
            

            const createItemResponse = await getMondayDetails(apiKeyMonday, parentItemQuery)

            const parentItemId = operation === "Create" ? createItemResponse.create_item.id : createItemResponse.change_multiple_column_values.id

            let columnQuery = `query { 
                boards(ids: ${subitemId}) { 
                    id 
                    name 
                    columns { id title type } 
                } 
            }`
            let subitemColumn = await getMondayDetails(apiKeyMonday, columnQuery);
            subitemColumn = subitemColumn.boards[0].columns

            let subProductCol = subitemColumn.find(col => col.title === "Product/Service Name")?.id;
            let subDescriptionCol = subitemColumn.find(col => col.title === "Product Description")?.id;
            let subQuantityCol = subitemColumn.find(col => col.title === "Quantity")?.id;
            let subSingleItemAmountCol = subitemColumn.find(col => col.title === "Single Item Amount")?.id;
            let subTotalAmountCol = subitemColumn.find(col => col.title === "Total Amount")?.id;

            const subitemMutations = data.Line
                .filter(item => item.Id)
                .map((item, index) => `
              create_subitem_${index}: create_subitem(
                parent_item_id: ${parentItemId},
                item_name: "Lineitem ${index + 1 || ''}",
                column_values: "{\\"${subProductCol}\\": \\"${item.SalesItemLineDetail?.ItemRef?.name || ''}\\", 
                                 \\"${subDescriptionCol}\\": \\"${item.Description || ''}\\", 
                                 \\"${subQuantityCol}\\": ${item.SalesItemLineDetail?.Qty || 0}, 
                                 \\"${subSingleItemAmountCol}\\": ${item.SalesItemLineDetail?.UnitPrice || 0}, 
                                 \\"${subTotalAmountCol}\\": ${item.Amount || 0} }"
              ) {
                id
                board { id }
              }
            `).join("\n");

            const query = `mutation { ${subitemMutations} }`;
            await getMondayDetails(apiKeyMonday, query);


            return parentItemId
        }
        else {
            let customerNameCol = invoiceCustomerColumn.find(col => col.title === "Customer Name")?.id;
            let openBalCol = invoiceCustomerColumn.find(col => col.title === "Open Balance")?.id;
            let emailCol = invoiceCustomerColumn.find(col => col.title === "Email")?.id;
            let phoneCol = invoiceCustomerColumn.find(col => col.title === "Phone Number")?.id;
            let addressCol = invoiceCustomerColumn.find(col => col.title === "Address")?.id;
            let creationDateCol = invoiceCustomerColumn.find(col => col.title === "Creation Date")?.id;
            let updatedDateCol = invoiceCustomerColumn.find(col => col.title === "Updated Date")?.id;
            let buttonCol = invoiceCustomerColumn.find(col => col.title === "QB Customer")?.id;

            let createdDate = data.MetaData.CreateTime.split('T')[0]
            let updatedDate = data.MetaData.LastUpdatedTime.split('T')[0];

            const createCustomerItemQuery = operation === "Create" ? `mutation {
                create_item(
                    board_id: ${mondayBoardId},
                    item_name: "Customer ${data.Id}",
                    column_values: "{\\"${customerNameCol}\\":\\"${data.DisplayName}\\",\\"${openBalCol}\\":\\"${data.Balance}\\", \\"${emailCol}\\":\\"${data.PrimaryEmailAddr?.Address || ''}\\", \\"${phoneCol}\\":\\"${data.PrimaryPhone?.FreeFormNumber || ''}\\", \\"${addressCol}\\":\\"${data.BillAddr?.Line1 || ''}, ${data.BillAddr?.City || ''}, ${data.BillAddr?.CountrySubDivisionCode || ''} ${data.BillAddr?.PostalCode || ''}\\", \\"${creationDateCol}\\":\\"${createdDate}\\", \\"${updatedDateCol}\\":\\"${updatedDate}\\"}"
                ) {
                    id
                }
            }`: `mutation {
                change_multiple_column_values(
                    board_id: ${mondayBoardId},
                    item_id:${details.mondayCustomerId},
                     column_values: "{\\"${customerNameCol}\\":\\"${data.DisplayName}\\",\\"${openBalCol}\\":\\"${data.Balance}\\", \\"${emailCol}\\":\\"${data.PrimaryEmailAddr?.Address || ''}\\", \\"${phoneCol}\\":\\"${data.PrimaryPhone?.FreeFormNumber || ''}\\", \\"${addressCol}\\":\\"${data.BillAddr?.Line1 || ''}, ${data.BillAddr?.City || ''}, ${data.BillAddr?.CountrySubDivisionCode || ''} ${data.BillAddr?.PostalCode || ''}\\", \\"${creationDateCol}\\":\\"${createdDate}\\", \\"${updatedDateCol}\\":\\"${updatedDate}\\"}"
             ) {
                    id
                }
            }`


            let createItemResponse = await getMondayDetails(apiKeyMonday, createCustomerItemQuery);

            return operation === "Create" ? createItemResponse.create_item?.id : createItemResponse.change_multiple_column_values?.id;
        }

    } catch (error) {
        console.log("Error:", error.message);
    }
}

router.post("/qbWebhook", async (req, res) => {
    console.log("QB Webhook received");

    try {
        const eventData = req.body
        if (!eventData.eventNotifications || !eventData.eventNotifications.length) {
            return res.status(400).json({ error: "Invalid event notification format" });
        }

        res.status(200).send("Webhook received");

        const eventNotification = eventData.eventNotifications[0];
        const realmId = eventNotification.realmId;
        const qbData = eventNotification?.dataChangeEvent?.entities[0];

        if (!qbData?.id || !realmId) {
            console.error("Missing required QuickBooks data");
            return;
        }

        if (!["Customer", "Invoice"].includes(qbData.name)) return;

        const type = qbData.name.toLowerCase();

        const tokens = await getTokens(realmId);
        if (!tokens) {
            console.error("No tokens found for realmId:", realmId);
            return;
        }

        const {
            qbAccessToken,
            qbRefreshToken,
            mondayAccessToken,
            mondayInvoiceBoardId,
            mondayCustomerBoardId,
            subitemBoardId,
            sandboxOrProduction
        } = tokens;

        const details = await handleQuickbookMondayData(
            [realmId, qbData.id],
            type === "customer"
                ? "SELECT * FROM quickbookMonday_Data WHERE realmId = ? AND qbCustomerId = ?"
                : "SELECT * FROM quickbookMonday_Data WHERE realmId = ? AND qbInvoiceId = ?"
        );

        const now = new Date();
        // if (details) {
        //     const lastUpdate = new Date(details.updated_at);
        //     if ((now - lastUpdate) / 1000 < 30) {
        //         console.log("Skipping update due to recent change");
        //         return;
        //     }
        // }

        const response = await getQBInvoiceCutomer(realmId, qbData.id, qbAccessToken, qbRefreshToken, type,sandboxOrProduction);
        console.log("response data",response);
        
        const data = type === "customer" ? response.data.Customer : response.data.Invoice;

        const operationType = details
            ? qbData.operation === "Delete"
                ? "Delete"
                : "Update"
            : "Create";

        const itemId = await createMondayInvoiceCustomer(
            data,
            mondayAccessToken,
            type === "customer" ? mondayCustomerBoardId : mondayInvoiceBoardId,
            type,
            subitemBoardId,
            operationType,
            details
        );


        if (!details && itemId) {
            console.log("Inserting new record into DB");
            await handleQuickbookMondayData(
                [
                    realmId,
                    type === "customer" ? mondayCustomerBoardId : mondayInvoiceBoardId,
                    type === "invoice" ? qbData.id : "",
                    type === "invoice" ? itemId : "",
                    type === "customer" ? qbData.id : "",
                    type === "customer" ? itemId : "",
                    now,
                ],
                "INSERT INTO quickbookMonday_Data (realmId, boardId, qbInvoiceId, mondayInvoiceId, qbCustomerId, mondayCustomerId, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
        } else if (details) {
            console.log("Updating existing record timestamp in DB");
            await handleQuickbookMondayData(
                [now, realmId, type === "customer" ? qbData.id : "", type === "invoice" ? qbData.id : ""],
                "UPDATE quickbookMonday_Data SET updated_at = ? WHERE realmId = ? AND (qbCustomerId = ? OR qbInvoiceId = ?)"
            );
        }
    } catch (err) {
        console.error("Error processing webhook:", err.message);
    }
});

async function createInvoiceColumns(mondayApiKey, invoiceBoard) {
    try {
        const queryData = `
        mutation {
            column1: create_column(board_id: ${invoiceBoard}, title: "Invoice #", column_type: numbers) { id }
            column2: create_column(board_id: ${invoiceBoard}, title: "Customer Name", column_type: long_text) { id }
            column3: create_column(
                board_id: ${invoiceBoard}, 
                title: "Invoice Status", 
                column_type: status, 
                defaults: "{\\"labels\\":{\\"0\\":\\"UnPaid\\",\\"1\\":\\"paid\\",\\"2\\":\\"Overdue\\",\\"3\\":\\"Partially Paid\\",\\"4\\":\\"Partially Paid and Overdue\\"}}"
            ) { id }
            column4: create_column(board_id: ${invoiceBoard}, title: "Due Date", column_type: date) { id }
            column5: create_column(board_id: ${invoiceBoard}, title: "Term", column_type: text) { id }
            column6: create_column(board_id: ${invoiceBoard}, title: "Total", column_type: numbers) { id }
            column7: create_column(board_id: ${invoiceBoard}, title: "Balance Due", column_type: numbers) { id }
            column8: create_column(board_id: ${invoiceBoard}, title: "Email", column_type: text) { id }
            column9: create_column(board_id: ${invoiceBoard}, title: "Address", column_type: long_text) { id }
            column10: create_column(board_id: ${invoiceBoard}, title: "Sub Total", column_type: numbers) { id }
            column11: create_column(board_id: ${invoiceBoard}, title: "Sales Tax", column_type: numbers) { id }
            column12: create_column(board_id: ${invoiceBoard}, title: "Creation Date", column_type: date) { id }
            column13: create_column(board_id: ${invoiceBoard}, title: "Updated Date", column_type: date) { id }
            column14: create_column(board_id: ${invoiceBoard}, title: "Invoice Link", column_type: long_text) { id }
        }`;
        // column15: create_column(board_id: ${invoiceBoard}, title: "Qb Invoice", column_type: button) { id }


        await getMondayDetails(mondayApiKey, queryData);

        let buttonCreate = `
        mutation {
            create_column(board_id: ${invoiceBoard}, title: "Qb Invoice", column_type: button) { id }
        }`;

        let res = await getMondayDetails(mondayApiKey, buttonCreate);
        console.log("response invoice", res);

        let buttonId = res?.create_column.id;

        let subitemId = await createSubitem(mondayApiKey, invoiceBoard);
        console.log("sub", subitemId);

        return { subitemId, buttonId };

    } catch (error) {
        const errorCode = error.response?.status || "Unknown Status Code";
        const errorMessage = error.response?.data?.error_message || error.message || "Unknown Error";

        console.error(`Error creating columns [${errorCode}]: ${errorMessage}`);
        throw new Error(`Error ${errorCode}: ${errorMessage}`);
    }
}


async function createSubitem(mondayApiKey, invoiceBoard) {
    try {
        let parentItemQuery = `mutation {
            create_item(
                board_id: ${invoiceBoard},
                item_name: "Tesing Item"
                
            ) {
                id
            }
        }`;

        const createItemResponse = await getMondayDetails(mondayApiKey, parentItemQuery)

        const parentItemId = createItemResponse.create_item.id;

        let ChildItemQuery = `mutation{ create_subitem (parent_item_id: ${parentItemId}, item_name: "Testing subitem") { id board { id }}}`;

        let subitemBoard = await getMondayDetails(mondayApiKey, ChildItemQuery)
        console.log(subitemBoard);


        let subitemBoardId = subitemBoard.create_subitem.board.id

        const queryData = `
    mutation {
        column1: create_column(board_id: ${subitemBoardId}, title: "Product/Service Name", column_type: text) { id }
        column2: create_column(board_id: ${subitemBoardId}, title: "Product Description", column_type: text) { id }
        column3: create_column(board_id: ${subitemBoardId}, title: "Quantity", column_type: numbers) { id }
        column4: create_column(board_id: ${subitemBoardId}, title: "Single Item Amount", column_type: numbers) { id }
        column5: create_column(board_id: ${subitemBoardId}, title: "Total Amount", column_type: numbers) { id }
    }`;

        await getMondayDetails(mondayApiKey, queryData);

        const deleteQueryData = `
        mutation {
            column1: delete_column(board_id: ${subitemBoardId}, column_id: "person") { id }
            column2: delete_column(board_id: ${subitemBoardId}, column_id: "status") { id }
            column3: delete_column(board_id: ${subitemBoardId}, column_id: "date0") { id }
        }`;

        await getMondayDetails(mondayApiKey, deleteQueryData);

        await itemDeleteMonday(mondayApiKey, parentItemId)
        return subitemBoardId;

    } catch (error) {
        const errorCode = error.response?.status || "Unknown Status Code";
        const errorMessage = error.response?.data?.error_message || error.message || "Unknown Error";

        console.error(`Error creating subitem [${errorCode}]: ${errorMessage}`);
        throw new Error(`Error ${errorCode}: ${errorMessage}`);
    }
}

async function itemDeleteMonday(mondayApiKey, parentItemId) {
    let query = `mutation {
  delete_item (item_id: ${parentItemId}) {
    id
  }
}`
    await getMondayDetails(mondayApiKey, query);

}
async function createCustomerColumns(mondayApiKey, customerBoard) {
    try {
        const queryData = `
        mutation {
            column1: create_column(board_id: ${customerBoard}, title: "Customer Name", column_type: text) { id }
            column2: create_column(board_id: ${customerBoard}, title: "Open Balance", column_type: numbers) { id }
            column3: create_column(board_id: ${customerBoard}, title: "Email", column_type: text) { id }
            column4: create_column(board_id: ${customerBoard}, title: "Phone Number", column_type: text) { id }
            column5: create_column(board_id: ${customerBoard}, title: "Address", column_type: text) { id }
            column6: create_column(board_id: ${customerBoard}, title: "Creation Date", column_type: date) { id }
            column7: create_column(board_id: ${customerBoard}, title: "Updated Date", column_type: date) { id }

        }`;

        let response = await getMondayDetails(mondayApiKey, queryData);
        console.log("response customer", response);


        let buttonCreate = `
        mutation {
           create_column(board_id: ${customerBoard}, title: "QB Customer", column_type: button) { id }  
        }`;

        let res = await getMondayDetails(mondayApiKey, buttonCreate);
        console.log("response invoice", res);

        let buttonId = res?.create_column.id;


        console.log("Columns created successfully, Button Column ID:", buttonId);

        return buttonId;

    } catch (error) {
        console.error("Error creating customer columns:", error.message);
        throw error;
    }
}

async function createMondayWorkspaceAndBoards(mondayApiKey) {
    console.log("Creating workspace & boards...");

    try {
        const workspaceId = await createWorkspace(mondayApiKey);

        const invoiceBoard = await createBoard(mondayApiKey, workspaceId, "QuickBooks-Monday Invoices");
        const customerBoard = await createBoard(mondayApiKey, workspaceId, "QuickBooks-Monday Customer");

        let invoiceIds = await createInvoiceColumns(mondayApiKey, invoiceBoard);
        console.log("Invoice IDs:", invoiceIds);

        let columnId = await createCustomerColumns(mondayApiKey, customerBoard);

        const webhookUrl = "https://api.vtecknologies.com/mondayqb/mondayWebhook";

        let invoiceWebhook = ` 
            mutation { 
                create_webhook(
                    url: "${webhookUrl}", 
                    event: change_specific_column_value, 
                    board_id: ${invoiceBoard}, 
                    config: "{\\"columnId\\": \\"${invoiceIds.buttonId}\\"}"
                ) { id board_id } 
            }
        `;
        let webhookResponse = await getMondayDetails(mondayApiKey, invoiceWebhook);
        console.log("Webhook Created:", webhookResponse.create_webhook);

        let customerWebhook = `mutation { 
             create_webhook(
                url: "${webhookUrl}", 
                event: change_specific_column_value, 
                board_id: ${customerBoard}, 
                config: "{\\"columnId\\": \\"${columnId}\\"}"
            ) { id board_id } 
        }`;
        let customerWebhookResponse = await getMondayDetails(mondayApiKey, customerWebhook);
        console.log('Customer Webhook Created:', customerWebhookResponse.create_webhook);

        return { invoiceBoard, customerBoard, subitemBoard: invoiceIds.subitemId };
    } catch (err) {
        console.error("❌ Error creating workspace or boards:", err.response?.data || err.message);
        return { error: "Monday API workspace creation failed: " + (err.response?.data || err.message) };
    }
}


router.post("/mondayWebhook", async (req, res) => {
    console.log("Monday webhook received:", req.body);

    if (req.body.challenge) {
        return res.status(200).send(req.body);
    }

    let itemData = req.body.event;
    let board = itemData.boardId;
    let pulse = itemData.pulseId;

    try {
        const details = await handleQuickbookMondayData(
            [board, board, board],
            "SELECT * FROM quickbook_Monday WHERE mondayInvoiceBoardId = ? OR mondayCustomerBoardId = ? OR subitemBoardId=?"
        );

        if (!details) {
            return res.status(400).json({ error: "Board details not found" });
        }
        let type = details.mondayInvoiceBoardId == board ? "invoice" : details.mondayCustomerBoardId == board ? "customer" : "";
        if (!type) {
            return res.status(400).json({ error: "Invalid board type" });
        }

        let query = "";
        let params = [];

        if (type === "invoice") {
            query = `SELECT * FROM quickbookMonday_Data WHERE boardId = ? AND mondayInvoiceId = ?`;
            params = [board, pulse];
        } else if (type === "customer") {
            query = `SELECT * FROM quickbookMonday_Data WHERE boardId = ? AND mondayCustomerId = ?`;
            params = [board, pulse];
        }

        const editDetails = await handleQuickbookMondayData(params, query);

        const currentTime = new Date();
        // if (editDetails?.updated_at) {
        //     const lastUpdateTime = new Date(editDetails.updated_at);
        //     const timeDifference = (currentTime - lastUpdateTime) / 1000;

        //     if (timeDifference < 30) {
        //         return res.status(400).json({ error: "Updates are only allowed after 30 seconds." });
        //     }
        // }

        const itemDetails = await getMondayItemDetails(pulse,details.mondayAccessToken);
        console.log("item details");
        

        if (type === "invoice") {
            let isLine = itemDetails.column_values[1]?.text && itemDetails.column_values[3]?.text
            if (isLine) {
                for (let subitem of itemDetails.subitems) {
                    if (!subitem.column_values[0]?.text || !subitem.column_values[2]?.text || !subitem.column_values[3]?.text) {
                        isLine = false;
                        break;
                    }
                }
            }

            if (isLine) {
                const invoice = await QBInvoice(
                    itemDetails, details.realmId, details.qbAccessToken, details.qbRefreshToken, details.account,
                    editDetails ? { type: "update", invoice: editDetails.qbInvoiceId } : { type: "create" },details.sandboxOrProduction
                )


                if (invoice) {
                    if (editDetails) {
                        console.log("edit");

                        await handleQuickbookMondayData(
                            [invoice, currentTime, editDetails.qbInvoiceId],
                            "UPDATE quickbookMonday_Data SET qbInvoiceId = ?, updated_at = ? WHERE qbInvoiceId = ?"
                        );
                    } else {
                        console.log("new");

                        await handleQuickbookMondayData(
                            [details.realmId, board, invoice, pulse, "", "", currentTime],
                            "INSERT INTO quickbookMonday_Data (realmId, boardId, qbInvoiceId, mondayInvoiceId, qbCustomerId, mondayCustomerId, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
                        );
                    }
                }
                return res.status(200).json({ message: "Invoice successfully created/updated." });
            } else {
                return res.status(400).json({
                    error: "Invoice creation/update requires Customer Name, Due Date, Sub-item Product Name, Description, Quantity, and Unit Price."
                });
            }
        } else if (type === "customer") {
            if (!itemDetails.column_values[0]?.text) {
                return res.status(400).json({ error: "Customer creation/update requires Customer Name" });
            }

            let customerName = escapeApostrophe(itemDetails.column_values[0].text);
            let customer = editDetails?await fetchQuickBooksData(
                `SELECT * FROM Customer WHERE Id = '${editDetails.qbCustomerId}'`, "customer",
                details.realmId, details.qbAccessToken, details.qbRefreshToken,details.sandboxOrProduction
            ):await fetchQuickBooksData(
                `SELECT * FROM Customer WHERE DisplayName = '${customerName}'`, "customer",
                details.realmId, details.qbAccessToken, details.qbRefreshToken,details.sandboxOrProduction
            )
            console.log("edit details",editDetails);
            

            customer = await createQBCustomer(
                { name: itemDetails.column_values[0].text, address: itemDetails.column_values[4].text, email: itemDetails.column_values[2].text,phone:itemDetails.column_values[3].text },
                details.realmId, details.qbAccessToken, details.qbRefreshToken,
                customer ? { type: "update", customer: customer.Id, synctoken: customer.SyncToken } : { type: "create" },details.sandboxOrProduction
            );

            if (customer?.Id) {
                if (editDetails) {
                    await handleQuickbookMondayData(
                        [customer.Id, currentTime, editDetails.qbCustomerId],
                        "UPDATE quickbookMonday_Data SET qbCustomerId = ?, updated_at = ? WHERE qbCustomerId = ?"
                    );
                } else {
                    await handleQuickbookMondayData(
                        [details.realmId, board, "", "", customer.Id, pulse, currentTime],
                        "INSERT INTO quickbookMonday_Data (realmId, boardId, qbInvoiceId, mondayInvoiceId, qbCustomerId, mondayCustomerId, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
                    );
                }
                console.log("success");
                return res.status(200).json({ message: "Customer successfully created/updated." });
            }
        }

        return res.status(500).json({ error: "Unexpected error occurred." });
    } catch (err) {
        console.error("Error:", err.response?.data || err.message);
        return res.status(500).json({ error: err.response?.data || err.message });
    }
});



async function getMondayItemDetails(pulseId, mondayApiKey) {
    const queryData = `
    query {
        items(ids: [${pulseId}]) {
            id
            name
            column_values {
                text
                value
                id
            }
            subitems {
                id
                name
                column_values {
                    text
                    value
                    id
                }
            }
        }
    }
    `;

    try {
        let itemResponse = await getMondayDetails(mondayApiKey, queryData)
        console.log('item get successfully', itemResponse.items[0]);

        const itemData = itemResponse.items[0];
        return itemData

    } catch (error) {
        console.error('Error fetching Monday.com item and subitems:', error);
        throw new Error('Failed to fetch Monday.com item and subitems');
    }
}

function escapeApostrophe(text) {
    return text.replace(/'/g, "\\'\\");
}

async function QBInvoice(itemDetails, id, qbAccessToken, qbRefreshToken, account, invoiceDetail,qbAcc) {

    try {
        let customerName = escapeApostrophe(itemDetails.column_values[1].text)

        let customer = await fetchQuickBooksData(`SELECT * FROM Customer WHERE DisplayName = '${customerName}'`, "customer", id, qbAccessToken, qbRefreshToken,qbAcc);
        console.log("customer", customer);

        if (!customer || customer.length === 0) {
            customer = await createQBCustomer({ name: customerName, address: itemDetails.column_values[8].text, email: itemDetails.column_values[7].text,phone:null }, id, qbAccessToken, qbRefreshToken, { type: "create" },qbAcc);
        }

        let index = 0
        for (let subitem of itemDetails.subitems) {

            let name = escapeApostrophe(subitem.column_values[0].text);
            let item = await fetchQuickBooksData(`SELECT * FROM Item WHERE FullyQualifiedName = '${name}'`, "item", id, qbAccessToken, qbRefreshToken,qbAcc);

            if (!item || item.length === 0) {
                const createdItem = await createQBItem({ name, discription: subitem.column_values[1].text ? subitem.column_values[1].text : "", quantity: subitem.column_values[2].text, amount: subitem.column_values[3].text }, id, qbAccessToken, qbRefreshToken, account,qbAcc);
                console.log("created item", createdItem);
                itemDetails.subitems[index].FullyQualifiedName = createdItem.item.FullyQualifiedName
                itemDetails.subitems[index].qbItemId = createdItem.item.Id

            } else {
                itemDetails.subitems[index].FullyQualifiedName = item.FullyQualifiedName
                itemDetails.subitems[index].qbItemId = item.Id
            }
            index++
        }

        const lineItems = itemDetails.subitems.map(subitem => ({
            Amount: Number(subitem.column_values[3].text) * Number(subitem.column_values[2].text),
            SalesItemLineDetail: {
                ItemRef: {
                    value: subitem.qbItemId,
                    name: subitem.FullyQualifiedName,
                },
                Qty: Number(subitem.column_values[2].text),
                UnitPrice: Number(subitem.column_values[3].text)
            },
            Description: subitem.column_values[1].text,
            DetailType: "SalesItemLineDetail"
        }));

        // UnitPrice: Number(subitem.column_values[3].text),

        let SyncToken = ""
        if (invoiceDetail.type === "update") {
            let invoice = await fetchQuickBooksData(`SELECT * FROM Invoice WHERE Id = '${invoiceDetail.invoice}'`, "invoice", id, qbAccessToken, qbRefreshToken);
            console.log(invoice);

            SyncToken = invoice.SyncToken
        }

        let addressParts =  itemDetails.column_values[8].text ?  itemDetails.column_values[8].text.split(",") : [];

        const raw = invoiceDetail.type === "create" ? JSON.stringify({
            Line: lineItems,
            CustomerRef: {
                value: customer.Id,
                name: itemDetails.column_values[1].text
            },
            BillAddr: {
                CountrySubDivisionCode: addressParts[2] ? addressParts[2].trim() : "",
                City: addressParts[1] ? addressParts[1].trim() : "",
                PostalCode:  addressParts[3] ? addressParts[3].trim() : "",
                Line1: addressParts[0] ? addressParts[0].trim() : ""
            },
            DueDate: itemDetails.column_values[3].text,
        }) : JSON.stringify({
            Line: lineItems,
            CustomerRef: {
                value: customer.Id,
                name: itemDetails.column_values[1].text
            },
            BillAddr: {
                CountrySubDivisionCode: addressParts[2] ? addressParts[2].trim() : "",
                City: addressParts[1] ? addressParts[1].trim() : "",
                PostalCode:  addressParts[3] ? addressParts[3].trim() : "",
                Line1: addressParts[0] ? addressParts[0].trim() : ""
            },
            DueDate: itemDetails.column_values[3].text,
            Id: invoiceDetail.invoice,
            SyncToken
        })
        console.log("create/update", raw);

        let invoice = await createUpdateQBInvoice(raw, id, qbAccessToken, qbRefreshToken, invoiceDetail.type)
        return invoice.Id

    }
    catch (err) {
        throw err
    }

}

async function createUpdateQBInvoice(raw, realmId, qbAccessToken, qbRefreshToken,qbAcc) {
    console.log(qbAcc);
            

    try {
        const response = await axios.post(`${qbAcc}/company/${realmId}/invoice`,
            raw,
            {
                headers: {
                    'Authorization': `Bearer ${qbAccessToken}`,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            })
        console.log(response.data);
        // await makeQBPayment()

        return response.data.Invoice;
    } catch (error) {
        if (error.response && error.response.status === 401) {
            console.log("Access token expired, refreshing...");

            const response = await axios.post("https://api.vtecknologies.com/mondayqb/refreshQbToken", {
                realmId: realmId,
                refreshToken: qbRefreshToken
            });
            qbAccessToken = response.data.access_token
            if (response.data.access_token) {
               return await createQBInvoice(raw, realmId, qbAccessToken, response.data.refresh_token,qbAcc)
            }
        } else {
            console.log(error.response ? error.response.data.Fault?.Error[0]?.Message : error);

            return error.response ? error.response.data.Fault?.Error[0]?.Message : error;

        }

    }

}

// async function makeQBPayment(realmId, qbAccessToken, qbRefreshToken) {
//     try {
//         const response = await axios.post(`https://sandbox-quickbooks.api.intuit.com/v3/company/${realmId}/payment`,
//             raw,
//             {
//                 headers: {
//                     'Authorization': `Bearer ${qbAccessToken}`,
//                     'Content-Type': 'application/json',
//                     'Accept': 'application/json'
//                 }
//             });
//         console.log(response.data);

//         return response.data;
//     } catch (error) {
//         if (error.response && error.response.status === 401) {
//             console.log("Access token expired, refreshing...");

//             const response = await axios.post("https://api.vtecknologies.com/mondayqb/refreshQbToken", {
//                 realmId: realmId,
//                 refreshToken: qbRefreshToken
//             });
//             qbAccessToken = response.data.access_token
//             if (response.data.access_token) {
//                return await makeQBPayment()
//             }
//         } else {
//             return error.response ? error.response.data : error;
//         }
//     }

// }

async function fetchQuickBooksData(query, type, realmId, qbAccessToken, qbRefreshToken,qbAcc) {
    let data = query;
    console.log("fetch",qbAcc);
            

    let config = {
        method: 'post',
        url: `${qbAcc}/company/${realmId}/query`,
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/text',
            'Authorization': `Bearer ${qbAccessToken}`,
        },
        data: data
    };

    try {
        const response = await axios.request(config);
        const entityMap = {
            customer: "Customer",
            item: "Item",
            invoice: "Invoice",
            account: "Account"
        };

        return entityMap[type] ? response.data.QueryResponse[entityMap[type]]?.[0] || null : null;

    } catch (error) {
        if (error.response && error.response.status === 401) {
            console.log("Access token expired, refreshing...");

            const response = await axios.post("https://api.vtecknologies.com/mondayqb/refreshQbToken", {
                realmId: realmId,
                refreshToken: qbRefreshToken
            });

            qbAccessToken = response.data.access_token
            if (response.data.access_token) {
               return await fetchQuickBooksData(query, type, realmId, qbAccessToken, response.data.refresh_token,qbAcc)
            }
        } else {
            throw error;
        }
    }
}
async function createQBCustomer(customer, realmId, qbAccessToken, qbRefreshToken, customerDetails,qbAcc) {
    try {
        let addressParts = customer.address ? customer.address.split(",") : [];

        let email = customer.email;
        let raw = customerDetails.type === "create"
            ? JSON.stringify({
                GivenName: customer.name,
                DisplayName: customer.name,
                PrimaryEmailAddr: {
                    Address: email
                },
                PrimaryPhone:{
                    FreeFormNumber:customer.phone
                },
                BillAddr: {
                    CountrySubDivisionCode: addressParts[2] ? addressParts[2].trim() : "",
                    City: addressParts[1] ? addressParts[1].trim() : "",
                    PostalCode:  addressParts[3] ? addressParts[3].trim() : "",
                    Line1: addressParts[0] ? addressParts[0].trim() : ""
                }
            })
            : JSON.stringify({
                Id: customerDetails.customer,
                SyncToken: customerDetails.synctoken,
                GivenName: customer.name,
                DisplayName: customer.name,
                PrimaryEmailAddr: {
                    Address: email
                },
                PrimaryPhone:{
                    FreeFormNumber:customer.phone
                },
                BillAddr: {
                    CountrySubDivisionCode: addressParts[2] ? addressParts[2].trim() : "",
                    City: addressParts[1] ? addressParts[1].trim() : "",
                    PostalCode:  addressParts[3] ? addressParts[3].trim() : "",
                    Line1: addressParts[0] ? addressParts[0].trim() : ""
                }
            });
            console.log(qbAcc);
            
        const response = await axios.post(
            `${qbAcc}/company/${realmId}/customer`,
            raw,
            {
                headers: {
                    'Authorization': `Bearer ${qbAccessToken}`,
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                }
            }
        );
        return response.data;
    } catch (error) {
        if (error.response && error.response.status === 401) {
            console.log("Access token expired, refreshing...");

            const response = await axios.post("https://api.vtecknologies.com/mondayqb/refreshQbToken", {
                realmId: realmId,
                refreshToken: qbRefreshToken
            });

            qbAccessToken = response.data.access_token;
            if (response.data.access_token) {
                return await createQBCustomer(customer, realmId, qbAccessToken, response.data.refresh_token, customerDetails,qbAcc);
            }
        } else {
            console.log(error.response?.data?.Fault?.Error[0]?.Message);
            
            throw error.response?.data?.Fault?.Error[0]?.Message || error.message;
        }
    }
}

async function createQBItem(item, realmId, qbAccessToken, qbRefreshToken, account,qbAcc) {
    console.log(qbAcc);
            
    const url = `${qbAcc}/company/${realmId}/item`;

    const itemData = {
        Name: item.name,
        IncomeAccountRef: {
            value: account,
        },
        Type: "Service",
        Active: true,
        Description: item.discription,
        UnitPrice: Number(item.amount),
    };
    console.log(itemData);

    try {
        const response = await axios.post(url, itemData, {
            headers: {
                'Authorization': `Bearer ${qbAccessToken}`,
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            }
        });

        console.log("Item Created:", response.data);

        return response.data;
    } catch (error) {

        if (error.response && error.response.status === 401) {
            console.log("Access token expired, refreshing...");

            const response = await axios.post("https://api.vtecknologies.com/mondayqb/refreshQbToken", {
                realmId: realmId,
                refreshToken: qbRefreshToken
            });
            qbAccessToken = response.data.access_token
            if (response.data.access_token) {
              return  await createQBItem(item, realmId, qbAccessToken, response.data.refresh_token, account,qbAcc)
            }
        } else {
            console.error("Error creating item:", error.response?.data?.Fault || error.message);

            throw error.response?.data?.Fault?.Error[0]?.Message || error.message;
        }
    }
}


async function getQBInvoiceCutomer(realmId, invoiceCustomerId, qbAccessToken, qbRefreshToken, type,qbAcc) {
    console.log(qbAcc);
            
    try {
        let invoice=await axios.get(`${qbAcc}/company/${realmId}/${type}/${invoiceCustomerId}`, {
            headers: {
                Accept: "application/json",
                Authorization: `Bearer ${qbAccessToken}`,
            },
        });
        
        return  invoice
    } catch (error) {
        if (error.response && error.response.status === 401) {
            console.log("Access token expired, refreshing...");

            const response = await axios.post("https://api.vtecknologies.com/mondayqb/refreshQbToken", {
                realmId: realmId,
                refreshToken: qbRefreshToken
            });
            qbAccessToken = response.data.access_token
            if (response.data.access_token) {
                return await getQBInvoiceCutomer(realmId, invoiceCustomerId, qbAccessToken, response.data.refresh_token, type,qbAcc)
               
            }
        } else {
            throw error;
        }
    }
}

let processedAuthCodes = new Set();

router.get("/callback", async (req, res) => {
    const { code: authCode, realmId } = req.query;
    
    if (processedAuthCodes.has(authCode)) {
        console.warn("🔁 Auth code already used:", authCode);
        processedAuthCodes.delete(authCode);
        return res.redirect("https://api.vtecknologies.com/qbmonday?installed=true");
    }

    processedAuthCodes.add(authCode);

    try {
        const { data } = await axios.post("https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer",
            new URLSearchParams({
                grant_type: "authorization_code",
                code: authCode,
                redirect_uri: "https://api.vtecknologies.com/mondayqb/callback",
                client_id: clientId,
                client_secret: clientSecret
            })
        );

        let qbAccessToken = data.access_token;
        let qbRefreshToken = data.refresh_token;

        db.query("SELECT account, mondayInvoiceBoardId, mondayCustomerBoardId, subitemBoardId FROM quickbook_Monday WHERE realmId = ?",
            [realmId], async (err, results) => {

                if (err) {
                    console.error("⚠️ Database Query Error:", err.message);
                    processedAuthCodes.delete(authCode);
                    return res.status(500).json({ error: "Internal Server Error" });
                }

                let account, invoiceBoard, customerBoard, subitemBoard;

                if (results.length) {
                    console.log("Reusing existing account & workspace");
                } else {
                    console.log("Creating new account & workspace...");
                    console.log("sanbox account",sandboxProduction);
                    
                    account = await createAccount(realmId, qbAccessToken,qbRefreshToken,sandboxProduction);
                    
                    try {
                        const newBoards = await createMondayWorkspaceAndBoards(mondayApiKey);
                        console.log("newboard", newBoards);
                        if(newBoards.error){
                            return res.redirect("https://api.vtecknologies.com/qbmonday?error=oauth");
                        }
                        else{
    
                        invoiceBoard = newBoards.invoiceBoard;
                        customerBoard = newBoards.customerBoard;
                        subitemBoard = newBoards.subitemBoard;
                        }
                    } catch (error) {
                        console.error("⚠️ Monday API Error:", error.message);
                        processedAuthCodes.delete(authCode);
                        return res.status(500).json({ error: error.message });
                    }
                }
                const query = results.length
                    ? "UPDATE quickbook_Monday SET qbAccessToken = ?, qbRefreshToken = ?, mondayAccessToken=? WHERE realmId = ?"
                    : "INSERT INTO quickbook_Monday (realmId, account, qbAccessToken, qbRefreshToken, mondayAccessToken, mondayInvoiceBoardId, mondayCustomerBoardId, subitemBoardId,sandboxOrProduction) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)";

                const params = results.length
                    ? [qbAccessToken, qbRefreshToken, mondayApiKey, realmId]
                    : [realmId, account, qbAccessToken, qbRefreshToken, mondayApiKey, invoiceBoard, customerBoard, subitemBoard,sandboxProduction];

                db.query(query, params, (err, result) => {
                    processedAuthCodes.delete(authCode);
                    if (err) {
                        console.error("⚠️ Database Insert/Update Error:", err.message);
                        return res.status(500).json({ error: "Internal Server Error" });
                    }
                    console.log("✅ Database operation successful!");
                    if (!res.headersSent) {
                        return res.redirect("https://api.vtecknologies.com/qbmonday?quickbooks_auth_success=true");
                    }
                });
            });

    } catch (error) {
        console.error("⚠️ OAuth Error:", error.message);
        processedAuthCodes.delete(authCode);
        return res.redirect("https://api.vtecknologies.com/qbmonday?error=oauth");
    }
})

async function createAccount(realmId, qbAccessToken,qbRefreshToken,qbAcc) {
    
    try {
        let account = await fetchQuickBooksData(`SELECT * FROM Account WHERE Name = 'Quickbooks Monday Items'`, "account", realmId, qbAccessToken,qbRefreshToken,qbAcc);
        
        if (!account) {
            
            const response = await axios.post(
                `${qbAcc}/company/${realmId}/account`,
                {
                    Name: "Quickbooks Monday Items",
                    AccountType: "Income",
                    AccountSubType: "SalesOfProductIncome"
                },
                {
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${qbAccessToken}`,
                        "Accept": "application/json"
                    }
                }
            );

            return response.data.Account.Id
        }
        else {
            return account.Id
        }
    } catch (error) {
        
        console.error("Error Creating Account:", error.response ? error.response.data : error.message);
        return null
    }
}

async function getMondayDetails(apiKeyMonday, queryData, retries = 3) {
    try {
        let data = JSON.stringify({ query: queryData });

        let config = {
            method: "post",
            url: "https://api.monday.com/v2",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiKeyMonday}`
            },
            data: data
        };

        const response = await axios.request(config);
        return response.data.data;

    } catch (error) {
        if (error.response) {
            const statusCode = error.response.status;
            if (statusCode === 429 && error.response.headers["retry-after"] && retries > 0) {
                let retryTime = parseInt(error.response.headers["retry-after"]) || 60;
                console.warn(`Rate limit exceeded. Retrying in ${retryTime} seconds...`);
                await new Promise(resolve => setTimeout(resolve, retryTime * 1000));
                return getMondayDetails(apiKeyMonday, queryData, retries - 1);
            }
            else {
                console.error("Error fetching Monday details:", error.response?.data || error.message);
                throw new Error(error.message);
            }
        }

        console.error("Error fetching Monday details:", error.response?.data || error.message);
        throw new Error(error.message);
    }
}

async function createBoard(mondayApiKey, workspaceId, boardName) {
    try {
        const queryData = `
        mutation {
            create_board (board_name: "${boardName}", board_kind: public, workspace_id: ${workspaceId}) {
                id
            }
        }`;

        let response = await getMondayDetails(mondayApiKey, queryData)

        if (response.create_board?.id) {
            return response.create_board.id;
        } else {
            throw new Error("Board creation failed: No ID returned.");
        }
    } catch (error) {
        console.error("Error creating board:", error.response?.data || error.message);
        throw error;
    }
}
async function createWorkspace(mondayApiKey) {
    try {
        const queryData = `
        mutation {
            create_workspace (name: "QuickBooks-Monday Workspace", kind: open, description: "This is a QuickBooks and Monday integration") {
                id
            }
        }`;

        let response = await getMondayDetails(mondayApiKey, queryData);

        if (response?.errors) {
            throw new Error(`Monday API Error: ${JSON.stringify(response.errors)}`);
        }

        if (response?.create_workspace?.id) {
            return response.create_workspace.id;
        } else {
            throw new Error("Workspace creation failed: No ID returned.");
        }
    } catch (error) {
        if (error.response?.status === 401) {
            console.error("Unauthorized (401): Invalid API key or permissions issue.");
        } else {
            console.error("Error creating workspace:", error.response?.data || error.message);
        }
        throw error;
    }
}



async function demo(apiKey, boardId, event, url) {

    async function createWebhook(apiKey, boardId, event, url) {

        const queryData = `
        mutation {
        create_webhook(
        board_id: ${boardId},
        url: "${url}",
        event: ${event}
        ) {
        id
        board_id
        event
        }
        }`;


        try {

            const webhookResponse = await getMondayDetails(apiKey, queryData);
            return webhookResponse.create_webhook;
        }
        catch (err) {
            console.log(err);
        }


    }
    await createWebhook(apiKey, boardId, event, url)
}

async function handleQuickbookMondayData(data, query) {
    return new Promise((resolve, reject) => {
        db.query(query, data, (err, results) => {
            if (err) {
                return reject(err);
            }
            resolve(results.length ? results[0] : null);
        });
    });
}

router.get("/dropTable", async (req, res) => {
    const tableName = "quickbookMonday_Data";
    const sql = `DROP TABLE IF EXISTS ??`;

    try {
        let a = db.query(sql, [tableName]);
        let b = db.query(sql, ["quickbook_Monday"]);
        res.json({ message: `Table ${a, b} dropped successfully.` });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post("/uninstall", async (req, res) => {
    const query1 = "DELETE FROM quickbook_Monday WHERE realmId = ?";
    const query2 = "DELETE FROM quickbookMonday_Data WHERE realmId = ?";

    try {
        db.query(query1, [req.body.realmId]);
        db.query(query2, [req.body.realmId]);
        res.status(200).json({ message: `All data for realmId ${req.body.realmId} removed successfully.` });
    } catch (error) {
        console.error("Error deleting data:", error);
        res.status(400).json({ message: `Error deleting data` });
    }
})

router.post("/mondayweb", (req, res) => {
    console.log(res);
    
    res.json("success");
});
module.exports = router;