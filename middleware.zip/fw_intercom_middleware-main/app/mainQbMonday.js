let error = document.getElementById("error");

async function connectQB(type) {
    let mondaySecret = "";
    let environment=document.getElementById("environment")

    if (type !== "reauthorize") {
        mondaySecret = document.getElementById("monday-accesstoken").value;

        if (!mondaySecret) {
            showError("⚠ Please Enter All Credentials");
            return;
        }
    }

    try {
        let response = await fetch("https://api.vtecknologies.com/mondayqb/connectQuickbooks", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ mondaySecret, accountType:environment.value })
        });

        let data = await response.json();

        if (data.url) {
            window.location.href = data.url;
        } else {
            showError("❌ Failed to get QuickBooks auth URL");
        }

    } catch (error) {
        showError("❌ Error: " + error.message);
    }
}

async function uninstall() {
    let realmId = document.getElementById("qbid").value;

    if (!realmId) {
        showError("⚠ Please Enter the QuickBooks Company ID");
        return;
    }
    try {
        let response = await fetch("https://api.vtecknologies.com/mondayqb/uninstall", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ realmId })
        });

        await response.json();
        $("#uninstall").hide();
        $("#info-form").show();
        setTimeout(() => {
            $("#uninstall").hide();
            $("#info-form").html(`
                <div class="card shadow-sm rounded-3 border-0" style="max-width: 600px; margin: auto;">
                    <div class="card-header bg-danger text-white text-center fw-bold">
                        ❌ App Uninstalled Successfully
                    </div>
                    <div class="card-body p-4 text-center">
                        <p>The <b>Monday & QuickBooks Integration</b> has been uninstalled.</p>
                        
                        <hr>
    
                        <h5>⚠ Important Note:</h5>
                        <p>You <b>can no longer sync</b> invoices or customers between QuickBooks and Monday.</p>    
                        <hr>
    
                        <a href="https://api.vtecknologies.com/qbmonday?install=true" class="btn btn-primary">🔄 Reinstall Now</a>
                    </div>
                </div>
            `).fadeIn();
        }, 10 * 1000);

    } catch (error) {
        showError("❌ Error: " + error.message);
    }
}



$(document).ready(function () {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get("quickbooks_auth_success") === "true") {
        $("#quickbooks-form").hide();
        $("#reauthorized").hide();
        $("#info-form").show();
        $("#uninstall").hide();
        document.getElementById("info-form").innerHTML = `
        <div class="card shadow-sm rounded-3 border-0" style="max-width: 600px; margin: auto;">
            <div class="card-header bg-success text-white text-center fw-bold">
                ✅ App Already Installed
            </div>
            <div class="card-body p-4 text-center">
                <p><b>Your QuickBooks-Monday integration is already set up and working fine.</b></p>
    
                <hr>
    
                <h5>🔍 What this means:</h5>
                <ul class="text-start">
                    <li>Your QuickBooks account is successfully linked with Monday.com.</li>
                    <li>All necessary workspaces and boards have been created.</li>
                    <li>Data synchronization between QuickBooks and Monday is active.</li>
                </ul>
    
                <hr>
    
                <h5>⚡ Next Steps:</h5>
                <ul class="text-start">
                    <li>If you want to reinstall, <b>first uninstall</b> the app and try again.</li>
                    <li>Need help? Contact support for troubleshooting.</li>
                </ul>
    
                <hr>
    
                <a href="https://api.vtecknologies.com/qbmonday?uninstall=true" class="btn btn-danger">🗑 Uninstall App</a>
            </div>
        </div>
    `;
    
    }
    else if (urlParams.get("reauthorize") === "true") {
        $("#quickbooks-form").hide();
        $("#reauthorized").show();
        $("#info-form").hide();
        $("#uninstall").hide();
    }
    else if (urlParams.get("uninstall") === "true") {
        $("#quickbooks-form").hide();
        $("#reauthorized").hide();
        $("#info-form").hide();
        $("#uninstall").show();
    }

    else if (urlParams.get("install") === "true") {
        $("#quickbooks-form").show();
        $("#reauthorized").hide();
        $("#info-form").hide();
        $("#uninstall").hide();
    }
    else if (urlParams.get("installed") === "true") {
        console.log("Installation process started...");

        $("#quickbooks-form, #reauthorized, #uninstall").hide();
        $("#info-form").show();
        $(".loading").show();

        setTimeout(() => {
            $(".loading").hide();
            $(".success-message").fadeIn();

            $("#info-form").html(`
                <div class="card shadow-sm rounded-3 border-0" style="max-width: 600px; margin: auto;">
                    <div class="card-header bg-success text-white text-center fw-bold">
                        ✅ App Installation Successful!
                    </div>
                    <div class="card-body p-4">
                        <p><b>Next Steps:</b></p>
                        <p>Go to the <b>Monday application</b> and locate the <b>Monday & QuickBooks Integration</b> workspace.</p>
                        
                        <hr>
        
                        <h5>📜 Creating an Invoice</h5>
                        <ul>
                            <li><b>Customer Name:</b> Required (New or existing customer).</li>
                            <li><b>At least one Line Item:</b> Every invoice needs at least one product/service.</li>
                            <li><b>For each Line Item:</b>
                                <ul>
                                    <li>Item Name</li>
                                    <li>Quantity (Single Unit)</li>
                                    <li>Product Price</li>
                                </ul>
                            </li>
                        </ul>
                        <p>Click <b>Send</b>, and the invoice will be created in QuickBooks.</p>
        
                        <hr>
        
                        <h5>👤 Creating a Customer</h5>
                        <p><b>Customer Name</b> is mandatory.</p>
                        <p>Click <b>Send</b>, and the customer will be saved & synced with QuickBooks.</p>
        
                        <hr>
        
                        <h5>💳 Managing Invoice Payments</h5>
                        <ul>
                            <li><b>Payments should be made in QuickBooks.</b></li>
                            <li>After payment, update the invoice in Monday.</li>
                            <li>Sync ensures both platforms stay updated.</li>
                        </ul>
                    </div>
                </div>
            `);

        }, 90000);

    }

    else if (urlParams.get("error") === "oauth") {
        $("#quickbooks-form").hide();
        $("#reauthorized").hide();
        $("#info-form").show();
        $("#uninstall").hide();
    
        document.getElementById("info-form").innerHTML = `
            <div class="card shadow-sm rounded-3 border-0" style="max-width: 600px; margin: auto;">
                <div class="card-header bg-danger text-white text-center fw-bold">
                    ❌ Installation Failed
                </div>
                <div class="card-body p-4 text-center">
                    <p><b>Reason:</b> App not installed. Please check your <b>Monday API key</b> and try again.</p>
    
                    <hr>
    
                    <h5>🔧 Troubleshooting Steps:</h5>
                    <ul class="text-start">
                        <li>Ensure you have entered the correct <b>Monday API Key</b>.</li>
                        <li>Check your internet connection and try again.</li>
                        <li>Verify that you have the necessary permissions in <b>Monday.com</b>.</li>
                        <li>Try reinstalling the app using the button below.</li>
                    </ul>
    
                    <hr>
    
                    <a href="https://api.vtecknologies.com/qbmonday?install=true" class="btn btn-primary">🔄 Reinstall Now</a>
                </div>
            </div>
        `;
    }
    
});

function showError(message) {
    error.innerHTML = `<div class="alert alert-danger">${message}</div>`;
    error.style.display = "block";

    setTimeout(() => {
        error.style.display = "none";
    }, 4000);
}