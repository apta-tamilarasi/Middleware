
let statusDiv = document.getElementsByClassName("status");
let head = document.getElementById("approvalhead")
let form = document.getElementById("approvalform")
let response = document.getElementsByClassName("response")
let afterResponse = document.getElementById("afterresponce")
let cardText = document.getElementsByClassName("card-text")
let approvalDate = document.getElementsByClassName("text-muted")
let params
let formattedDate


const getQueryParams = async () => {
    console.log(window.location);
    const params = new URLSearchParams(window.location.search);
    const encodedData = params.get('data');

    function base64Decode(str) {
        return decodeURIComponent(escape(atob(str)));
    }
    const decodedQueryString = base64Decode(encodedData);
    const decodedParams = new URLSearchParams(decodedQueryString);
    console.log(decodedParams);


    return {
        fdUrl: decodedParams.get("url"),
        ticket: decodedParams.get("ticket"),
        appId: decodedParams.get("appid"),
        requestId: decodedParams.get("requestId"),
        mail: decodedParams.get("mail")
    };

}

const approveDecline = async (status) => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');

    formattedDate = `${year}-${month}-${day} ${hours}:${minutes}`;
    params = await getQueryParams();

    let firstName = document.getElementById("firstname").value;
    let lastName = document.getElementById("lastname").value;
    let email = document.getElementById("email").value;
    console.log(firstName, lastName, email);


    if (firstName != "" && lastName != "" && email != "") {
        let mails = params.mail.split(",")
        let isMail = mails.find((e) => {
            return e === email
        })
        if (isMail) {
            let alert = document.getElementById("errorDiv")
            let para = document.getElementById("error")
            para.textContent = ""
            alert.style.display = "none"
            let isResponse = await databaseApproval(email)

            console.log(isResponse);
            if (isResponse.length > 0) {
                await alreadyResponsed(isResponse)
            }
            else if (isResponse.length === 0) {
                await newResponse(status, firstName, lastName, email, isResponse)
            }
            else {
                console.log(isResponse);
            }
        }
        else {

            let alert = document.getElementById("errorDiv")
            let para = document.getElementById("error")
            alert.style.display = "block"
            // document.getElementById("email").value=""
            para.textContent = `Validation failed, kindly access through the invited email`
            // setTimeout(() => {
            // para.textContent = ""
            // alert.style.display = "none"
            // }, 2000)

        }


    } else {
        console.log("fill all field");
        let alert = document.getElementById("errorDiv")
        let para = document.getElementById("error")
        alert.style.display = "block"
        para.textContent = ` All fields are manitory`
    }
};

const databaseApproval = async (email) => {
    try {
        const response = await fetch(`/approvalData?email=${email}&ticketId=${params.ticket}&appid=${params.appId}&requestId=${params.requestId}`);

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        console.log(data)
        return data
    } catch (error) {
        console.error('Fetch error:', error);
    }
}
const newResponse = async (status, firstName, lastName, email) => {
    try {
        const response = await fetch(`/updateApprovalData?email=${email}&status=${status}&name=${firstName} ${lastName}&ticketId=${params.ticket}&date=${formattedDate}&appid=${params.appId}&requestId=${params.requestId}`);

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        console.log(data);
        if (data.message === "Data updated successfully") {
            let data = {
                ticket: params.ticket,
                status: status,
                firstName,
                lastName,
                email
            }

            const updateFd = await fetch('/externalApproval', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    url: params.fdUrl,
                    data: data
                })
            });
            const fdRes = await updateFd.json()
            console.log(fdRes);

            if (fdRes.message === "success") {
                approveUpdate(status, firstName, lastName, email)
            }
            else {
                const response = fetch(`/deleteApprovalData?email=${email}&ticketId=${params.ticket}&appid=${params.appId}`, {
                    method: 'DELETE',
                });
                console.log(response);
                
                let alert = document.getElementById("errorDiv")
                let para = document.getElementById("error")
                alert.style.display = "block"
                para.textContent = `Can't update the ticket, try again`
            }

        }
    } catch (error) {
        console.error('Fetch error:', error);
    }


}

const alreadyResponsed = async (isResponse) => {

    document.getElementById("firstname").value = ""
    document.getElementById("lastname").value = ""
    document.getElementById("email").value = ""
    afterResponse.style.display = "block"

    head.style.display = "none"
    form.style.display = "none"
    if (isResponse[0].status === "approve") {
        response[0].style.display = "block"
        response[1].style.display = "none"
        statusDiv[0].textContent = `Already Ticket is ${isResponse[0].status}d by ${isResponse[0].name}`

    }
    else {
        statusDiv[1].textContent = `Already Ticket is ${isResponse[0].status}d by ${isResponse[0].name}`
        response[1].style.display = "block"
        response[0].style.display = "none"

    }

    cardText[0].textContent = `Ticket ${isResponse[0].ticketId} is ${isResponse[0].status}d by ${isResponse[0].name} at the Mail ${isResponse[0].email}`
    approvalDate[0].textContent = `${isResponse[0].status}d at ${isResponse[0].date}`

}

const approveUpdate = (status, firstName, lastName, email) => {
    head.style.display = "none"
    form.style.display = "none"
    afterResponse.style.display = "block"

    if (status === "approve") {
        response[0].style.display = "block"
        response[1].style.display = "none"
        statusDiv[0].textContent = `Ticket ${status}d Successfully`
    }
    else {
        statusDiv[1].textContent = `Ticket ${status}d Successfully`
        response[1].style.display = "block"
        response[0].style.display = "none"
    }

    cardText[0].textContent = `Ticket ${params.ticket} is ${status}d by ${firstName} ${lastName} at the Mail ${email}`
    approvalDate[0].textContent = `${status}d at ${formattedDate}`

    document.getElementById("firstname").value = ""
    document.getElementById("lastname").value = ""
    document.getElementById("email").value = ""
}