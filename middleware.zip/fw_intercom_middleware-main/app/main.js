let client;
let CRMfields = [];
let fieldInfo = [];
let fieldsData = [];
let appId;
//let zohoCredentials;
document.addEventListener("DOMContentLoaded", () => {
  client = ZAFClient.init();

  // zohoCredentials = localStorage.getItem("zoho_credentials");

  document
    .getElementById("auth-btn")
    .addEventListener("click", userAuthentication);
  document
    .getElementById("confirm-btn")
    .addEventListener("click", showCredentialContainer);
  client.metadata().then(function (metadata) {
    console.log(metadata);
    appId = metadata["appId"];
    window.email = metadata["settings"]["RegisteredEmail"];
    window.domain = metadata["settings"]["SubDomain"];
    fetchCRMcontactFields();
  });
});
const fetchCRMcontactFields = async () => {
  $("#loader").show();
  //await getAppid();
  console.log(appId);

  try {
    const res = await fetch("/isAuth", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ appId }),
    });
    const contentType = res.headers.get("content-type");

    if (contentType?.includes("application/json")) {
      let isAuth = await res.json();
      console.log(isAuth);

      if (isAuth.authentication) {
        fieldsData = isAuth.mapped_fields
          ? JSON.parse(isAuth.mapped_fields)
          : [];
        const crmRes = await fetch("/zohoCRMfields");
        const { data, code } = await crmRes.json();

        if (code === "SUCCESS") {
          CRMfields = data.fields;
          fetchZendeskContactFields();
          $(".edit-credential-btn").show();
          $("#field-mapping-div").show();
        } else {
          client.invoke(
            "notify",
            "Unable to fetch the Zoho CRM fields",
            "error"
          );
        }
      } else {
        $("#auth-card").show();
        $("#field-mapping-div").hide();
      }
    } else {
      const text = await res.text();
      console.log("Response text:", text);
    }
  } catch (error) {
    console.error("Error:", error);
    $("#error-div").show();
    client.invoke("notify", "Something went wrong", "error");
  } finally {
    $("#loader").hide();
  }
};

const fetchZendeskContactFields = () => {
  let zendeskFields = getDefaultZenFields();

  const options = {
    url: `/api/v2/user_fields`,
    type: "GET",
    contentType: "application/json",
    secure: true,
  };
  client.request(options).then(
    (data) => {
      zendeskFields = [...zendeskFields, ...data.user_fields];
      let container = document.getElementById("field-mapping-div");
      console.log("yes");

      CRMfields.map((crmField) => {
        let fieldLabelName = crmField.display_label;
        if (
          !getCrmDataTypeList().includes(crmField.data_type) &&
          !getCrmApiNameList().includes(crmField.api_name)
        ) {
          fieldLabelName =
            fieldLabelName === "Last Name" ? "Name" : fieldLabelName;
          const fieldId = crmField.api_name;
          const fieldType = crmField.data_type;
          let crmSubText = "";
          let textType = ["text", "textarea"];
          if (getNumberTypes().includes(fieldType)) {
            crmSubText = "Number";
          } else if (textType.includes(fieldType)) {
            crmSubText = "Text";
          } else if (fieldType === "date" || fieldType === "datetime") {
            crmSubText = "Date";
          } else if (fieldType === "website") {
            crmSubText = "URL";
          } else if (fieldType === "email") {
            crmSubText = "Email";
          } else if (fieldType === "picklist") {
            crmSubText = "Dropdown";
          } else if (fieldType === "phone") {
            crmSubText = "Phone";
          } else if (fieldType === "boolean") {
            crmSubText = "Checkbox";
          } else if (fieldType === "lookup") {
            crmSubText = "Lookup";
          }
          let row = document.createElement("div");
          row.className = "row text-center";
          let colOne = document.createElement("div");
          colOne.className = "col col-one";
          let h4 = document.createElement("h5");
          h4.textContent = fieldLabelName;
          let span_1 = document.createElement("span");
          span_1.innerText = crmSubText;
          span_1.className = "crm-field-type";
          colOne.append(h4, span_1);
          let colTwo = document.createElement("div");
          colTwo.className = "col";
          let select = document.createElement("fw-select");
          select.setAttribute("placeholder", "Select an option");
          select.id = fieldId;
          fieldInfo.push({
            fieldId,
            fieldType,
          });
          let options = [];
          zendeskFields.map((zenField) => {
            if (zenField.type != "regexp") {
              let subText = zenField.type;
              if (
                subText.length > 0 &&
                subText[0] === subText[0].toLowerCase()
              ) {
                subText = subText.charAt(0).toUpperCase() + subText.slice(1);
                subText = subText === "Integer" ? "Number" : subText;
              }
              let isCf = zenField.cf ? !zenField.cf : !zenField.cf;
              options.push({
                value: `${zenField.key},${isCf}`,
                text: zenField.title,
                subText,
              });
            }
          });
          select.options = options;
          select.addEventListener("fwChange", (e) =>
            validateFieldMapping(crmSubText, e)
          );
          for (const mapped_fields of fieldsData) {
            if (mapped_fields.CRM_fields === fieldId) {
              select.value = `${mapped_fields.zen_fields},${mapped_fields.zen_is_cf}`;
              break;
            }
          }
          colTwo.append(select);
          row.append(colOne, colTwo);
          container.append(row);
        }
      });
      let btn_row = document.createElement("div");
      btn_row.className = "row justify-content-md-center";
      btn_row.style.width = "58rem";
      btn_row.style.marginLeft = "12rem";
      let btn_col = document.createElement("div");
      btn_col.className = "col-md-5";
      btn_col.style.width = "100%";
      let btn = document.createElement("button");
      btn.className = "btn btn-secondary";

      btn.style.width = "100%";
      btn.style.background = "#03363d";
      btn.addEventListener("click", saveFields);
      let h6 = document.createElement("h4");
      h6.textContent = "Save Fields";
      btn.append(h6);
      btn_col.append(btn);
      btn_row.append(btn_col);
      container.append(btn_row);

      client.invoke("notify", "zendesk Fields fetched");
    },
    (error) => {
      console.error(error);
      let errorMsg = `Error ${error.status} ${error.statusText}`;
      client.invoke("notify", errorMsg, "error");
    }
  );
};
const userAuthentication = (e) => {
  e.preventDefault();
  const btn = document.getElementById("auth-btn");

  let authorizationCode = document.getElementById("authCode").value.trim();
  let clientId = document.getElementById("client-id").value.trim();
  let clientSecret = document.getElementById("client-secret").value.trim();
  let dc = document.getElementById("dc").value.trim();

  if (
    authorizationCode === "" ||
    clientId === "" ||
    clientSecret === "" ||
    dc === ""
  ) {
    client.invoke("notify", "Fill out the required fields", "error");
    return;
  }
  btn.disabled = true;
  btn.textContent = "Please Wait...";
  const option = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      authorizationCode,
      clientId,
      clientSecret,
      dc,
      appId,
    }),
  };

  fetch("/auth", option)
    .then(async (res) => {
      console.log(await res.json());
      if (res.ok) {
        client.invoke("notify", "Connection created successfully", "success");
        document.getElementById("authCode").value = "";
        document.getElementById("client-id").value = "";
        document.getElementById("client-secret").value = "";
        document.getElementById("dc").value = "";
        $("#auth-card").hide();
        //$("#field-mapping-div").show();
        await fetchCRMcontactFields();
      } else {
        throw Error(
          "Could not create a connection with Zoho CRM. Verify your credentials and try again"
        );
      }
    })
    .catch((er) => {
      client.invoke("notify", er.message, "error");
      console.error(er);
    })
    .finally(() => {
      btn.disabled = false;
      btn.textContent = "Authorize";
    });
};
const validateFieldMapping = (fieldType, e) => {
  const selectedFieldType = e.detail.meta.selectedOptions[0].subText;
  if (fieldType != selectedFieldType) {
    client.invoke("notify", "Field type is not matched", "error");
    e.target.value = "";
  }
};

const saveFields = (e) => {
  fieldsData = fieldsData.length > 0 ? [] : fieldsData;
  fieldInfo.map((field) => {
    let inputValue = document.getElementById(field.fieldId).value.split(",");
    let zen_is_cf = inputValue[1];
    inputValue = inputValue[0];

    if (inputValue != "") {
      let obj = {
        CRM_fields: field.fieldId,
        zen_fields: inputValue,
        crm_field_type: field.fieldType,
        zen_is_cf,
      };
      fieldsData.push(obj);
    }
  });

  let options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      fields: fieldsData,
    }),
  };

  fetch("/webhook", options)
    .then(async (res) => {
      let payload = await res.json();

      if (payload) {
        fieldInfo.map((field) => {
          let inputValue = document.getElementById(field.fieldId).value;

          if (inputValue != "") {
            document.getElementById(field.fieldId).value = "";
          }
        });
        client.invoke("notify", "Saved", "success");
      }
    })
    .catch((er) => console.error(er));
};

const deleteTable = () => {
  fetch("/delete")
    .then(async () => {})
    .catch((er) => console.error(er));
};

const getAppid = async () => {
  const options = {
    url: `/api/v2/apps/owned.json`,
    type: "GET",
    contentType: "application/json",

    secure: true,
  };

  try {
    let data = await client.request(options);
    app_data = data.apps?.filter((app) => {
      return app.name === "Zendesk zohoCRM sync";
    });

    appId = app_data[0].id;
    console.log(appId);
  } catch (error) {
    console.error(error);
  }
};

const showCredentialContainer = () => {
  $("#field-mapping-div").hide();
  $(".edit-credential-btn").hide();
  $("#auth-card").show();

  let options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      appId,
    }),
  };

  fetch("/deleteAppData", options)
    .then(async (res) => {
      let payload = await res.json();
      console.log(payload);

      if (payload) {
        // fieldInfo.map((field) => {
        //   let inputValue = document.getElementById(field.fieldId).value;
        //   if (inputValue != "") {
        //     document.getElementById(field.fieldId).value = "";
        //   }
        // });
        //client.invoke("notify", "Saved", "success");
      }
    })
    .catch((er) => console.error(er));

  // const myModal = new bootstrap.Modal(document.getElementById("confirm"));
  // myModal.hide();
};

//window.addEventListener("load", (e) => {
//   console.log(e);
//   let currentUrl = window.location.href;
//   console.log(currentUrl);
// });
// "parameters": [{ "name": "token", "type": "oauth" }],
//   "oauth": {
//     "client_id": "<dynamic value>",
//     "client_secret": "<dynamic value>",
//     "authorize_uri": "https://accounts.zoho.com/oauth/v2/auth",
//     "access_token_uri": "https://accounts.zoho.com/oauth/v2/token",
//     "scope": "ZohoCRM.modules.ALL,ZohoCRM.settings.fields.ALL"
//   },
// https://accounts.zoho.com/oauth/v2/auth?scope=ZohoCRM.modules.ALL%2CZohoCRM.settings.fields.ALL&access_type=offline&prompt=consent&response_type=code&redirect_uri=https%3A%2F%2Foauth.freshdev.io%2Fauth%2Fcallback&state=203b1081530553e9fd297115b84014235d13c43792c65eebf31db25a85a5362d0d7b375c132d2c59d4b1360b2563f3f47897a2be32515cb8ab4418ead360727e3de9966c99aeeb9a&client_id=1000.5EV4J9FXAVEYGX9HB1LT5RAUD8R4KS

// fetch("/token", { code: authorizationCode })
//     .then((res) => {
//       console.log(res);
//     })
//     .catch((er) => {
//       console.error(er);
//     });
